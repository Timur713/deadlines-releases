﻿Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Keep the runtime beside the application. This avoids administrator rights and
# does not change PATH or install anything globally on the user's computer.
$projectRoot = Split-Path -Parent $PSScriptRoot
$runtimeRoot = Join-Path $projectRoot ".runtime"
$nodeRoot = Join-Path $runtimeRoot "node"
$statusFile = Join-Path $runtimeRoot "windows-status.txt"
$nodeRelease = "latest-v24.x"

function Set-LauncherStatus([string]$message) {
  New-Item -ItemType Directory -Force -Path $runtimeRoot | Out-Null
  [System.IO.File]::WriteAllText($statusFile, $message, [System.Text.Encoding]::UTF8)
}

function Install-PortableNode {
  Set-LauncherStatus "Первый запуск: скачиваем компоненты программы..."
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

  $architecture = if ($env:PROCESSOR_ARCHITEW6432) {
    $env:PROCESSOR_ARCHITEW6432
  } else {
    $env:PROCESSOR_ARCHITECTURE
  }
  $nodeArchitecture = if ($architecture -eq "ARM64") { "arm64" } else { "x64" }
  $releaseUrl = "https://nodejs.org/dist/$nodeRelease"
  $checksumsPath = Join-Path $runtimeRoot "SHASUMS256.txt"
  $archivePath = Join-Path $runtimeRoot "node.zip"
  $extractPath = Join-Path $runtimeRoot "node-extracted"

  Invoke-WebRequest -UseBasicParsing -Uri "$releaseUrl/SHASUMS256.txt" -OutFile $checksumsPath
  $checksumLine = Get-Content $checksumsPath | Where-Object {
    $_ -match "^[a-fA-F0-9]{64}\s+node-v[0-9.]+-win-$nodeArchitecture\.zip$"
  } | Select-Object -First 1

  if (-not $checksumLine) {
    throw "Не удалось найти подходящую версию Node.js для Windows ($nodeArchitecture)."
  }

  $checksumParts = $checksumLine -split "\s+", 2
  $expectedHash = $checksumParts[0].ToUpperInvariant()
  $archiveName = $checksumParts[1].Trim()
  Invoke-WebRequest -UseBasicParsing -Uri "$releaseUrl/$archiveName" -OutFile $archivePath

  $actualHash = (Get-FileHash -Algorithm SHA256 -Path $archivePath).Hash
  if ($actualHash -ne $expectedHash) {
    throw "Проверка загруженного Node.js завершилась ошибкой."
  }

  Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $extractPath
  Expand-Archive -Path $archivePath -DestinationPath $extractPath -Force
  $extractedNode = Get-ChildItem -Directory $extractPath | Select-Object -First 1
  if (-not $extractedNode -or -not (Test-Path (Join-Path $extractedNode.FullName "node.exe"))) {
    throw "Загруженный архив Node.js имеет неожиданный формат."
  }

  Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $nodeRoot
  Move-Item -Path $extractedNode.FullName -Destination $nodeRoot
  Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $extractPath
  Remove-Item -Force -ErrorAction SilentlyContinue $archivePath, $checksumsPath
}

try {
  New-Item -ItemType Directory -Force -Path $runtimeRoot | Out-Null
  $nodeExe = Join-Path $nodeRoot "node.exe"
  $npmCmd = Join-Path $nodeRoot "npm.cmd"

  if (-not (Test-Path $nodeExe) -or -not (Test-Path $npmCmd)) {
    Install-PortableNode
  }

  $env:PATH = "$nodeRoot;$env:PATH"
  $packageLock = Join-Path $projectRoot "package-lock.json"
  $dependenciesMarker = Join-Path $runtimeRoot "dependencies.sha256"
  $expectedDependenciesHash = (Get-FileHash -Algorithm SHA256 -Path $packageLock).Hash
  $installedDependenciesHash = if (Test-Path $dependenciesMarker) {
    (Get-Content -Raw $dependenciesMarker).Trim()
  } else {
    ""
  }

  $expressModule = Join-Path $projectRoot "node_modules\express"
  if ($installedDependenciesHash -ne $expectedDependenciesHash -or -not (Test-Path $expressModule)) {
    Set-LauncherStatus "Первый запуск: устанавливаем компоненты программы..."
    Push-Location $projectRoot
    try {
      & $npmCmd ci --no-audit --no-fund
      if ($LASTEXITCODE -ne 0) {
        throw "npm завершился с кодом $LASTEXITCODE."
      }
      [System.IO.File]::WriteAllText($dependenciesMarker, $expectedDependenciesHash)
    } finally {
      Pop-Location
    }
  }

  Set-LauncherStatus "Запускаем программу..."
  Set-Location $projectRoot
  & $nodeExe "src\server.js"
  exit $LASTEXITCODE
} catch {
  $message = $_.Exception.Message
  Set-LauncherStatus "Ошибка запуска: $message"
  exit 1
}
