﻿Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$projectRoot = Split-Path -Parent $PSScriptRoot
$serviceUrl = "http://localhost:3000"
$serviceProcess = $null
$serviceReady = $false
$stopping = $false
$browserOpened = $false
$runtimeRoot = Join-Path $projectRoot ".runtime"
$statusFile = Join-Path $runtimeRoot "windows-status.txt"
$bootstrapScript = Join-Path $PSScriptRoot "windows-bootstrap.ps1"
$updateProgressFlag = Join-Path $runtimeRoot "update-in-progress.flag"
$updateReadyFlag = Join-Path $runtimeRoot "update-ready.flag"
$updateErrorFile = Join-Path $runtimeRoot "update-error.txt"

$form = New-Object System.Windows.Forms.Form
$form.Text = "HR: контроль сроков"
$form.StartPosition = "CenterScreen"
$form.ClientSize = New-Object System.Drawing.Size(460, 190)
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.MinimizeBox = $true
$form.Font = New-Object System.Drawing.Font("Segoe UI", 10)

$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Text = "HR: контроль сроков"
$titleLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 15)
$titleLabel.AutoSize = $true
$titleLabel.Location = New-Object System.Drawing.Point(24, 22)
$form.Controls.Add($titleLabel)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = "Подготовка к запуску..."
$statusLabel.Location = New-Object System.Drawing.Point(27, 63)
$statusLabel.Size = New-Object System.Drawing.Size(405, 48)
$form.Controls.Add($statusLabel)

$openButton = New-Object System.Windows.Forms.Button
$openButton.Text = "Открыть программу"
$openButton.Location = New-Object System.Drawing.Point(27, 126)
$openButton.Size = New-Object System.Drawing.Size(190, 38)
$openButton.Enabled = $false
$form.Controls.Add($openButton)

$stopButton = New-Object System.Windows.Forms.Button
$stopButton.Text = "Остановить"
$stopButton.Location = New-Object System.Drawing.Point(235, 126)
$stopButton.Size = New-Object System.Drawing.Size(110, 38)
$stopButton.Enabled = $false
$form.Controls.Add($stopButton)

$closeButton = New-Object System.Windows.Forms.Button
$closeButton.Text = "Закрыть"
$closeButton.Location = New-Object System.Drawing.Point(355, 126)
$closeButton.Size = New-Object System.Drawing.Size(77, 38)
$form.Controls.Add($closeButton)

$healthTimer = New-Object System.Windows.Forms.Timer
$healthTimer.Interval = 600

function Test-ServiceReady {
  try {
    $request = [System.Net.HttpWebRequest]::Create("$serviceUrl/api/settings")
    $request.Method = "GET"
    $request.Timeout = 350
    $request.ReadWriteTimeout = 350
    $response = $request.GetResponse()
    $ok = [int]$response.StatusCode -eq 200
    $response.Close()
    return $ok
  } catch {
    return $false
  }
}

function Stop-ServiceProcess {
  if ($stopping) { return }
  $script:stopping = $true
  $healthTimer.Stop()

  if ($null -ne $serviceProcess -and -not $serviceProcess.HasExited) {
    & taskkill.exe /PID $serviceProcess.Id /T /F 2>$null | Out-Null
    try { $serviceProcess.WaitForExit(3000) | Out-Null } catch {}
  }

  $script:serviceReady = $false
  $openButton.Enabled = $false
  $stopButton.Enabled = $false
  $statusLabel.Text = "Программа остановлена."
  $script:stopping = $false
}

function Start-ServiceProcess {
  if (Test-Path $updateReadyFlag) {
    Remove-Item -Force -ErrorAction SilentlyContinue $updateReadyFlag, $updateProgressFlag, $updateErrorFile
  } elseif ((Test-Path $updateProgressFlag) -and -not (Test-Path $updateErrorFile)) {
    $updateAge = (Get-Date) - (Get-Item $updateProgressFlag).LastWriteTime
    if ($updateAge.TotalMinutes -le 15) {
      $statusLabel.Text = "Устанавливаем обновление. Не закрывайте это окно..."
      $stopButton.Enabled = $false
      $healthTimer.Start()
      return
    }
    Remove-Item -Force -ErrorAction SilentlyContinue $updateProgressFlag
  }

  if (Test-ServiceReady) {
    $statusLabel.Text = "Программа уже запущена. Открываем в браузере..."
    $openButton.Enabled = $true
    Start-Process $serviceUrl
    return
  }

  if (-not (Test-Path $bootstrapScript)) {
    $statusLabel.Text = "Не найден файл запуска scripts\windows-bootstrap.ps1."
    return
  }

  New-Item -ItemType Directory -Force -Path $runtimeRoot | Out-Null
  Remove-Item -Force -ErrorAction SilentlyContinue $statusFile

  $startInfo = New-Object System.Diagnostics.ProcessStartInfo
  $startInfo.FileName = "powershell.exe"
  $startInfo.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$bootstrapScript`""
  $startInfo.WorkingDirectory = $projectRoot
  $startInfo.UseShellExecute = $false
  $startInfo.CreateNoWindow = $true
  $startInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden

  $script:serviceProcess = New-Object System.Diagnostics.Process
  $serviceProcess.StartInfo = $startInfo
  if (-not $serviceProcess.Start()) {
    $statusLabel.Text = "Не удалось запустить программу. Закройте окно и попробуйте ещё раз."
    return
  }

  $statusLabel.Text = "Подготавливаем программу. При первом запуске это займёт несколько минут..."
  $stopButton.Enabled = $true
  $healthTimer.Start()
}

$healthTimer.Add_Tick({
  if (Test-Path $statusFile) {
    try {
      $launcherStatus = [System.IO.File]::ReadAllText($statusFile, [System.Text.Encoding]::UTF8)
      if ($launcherStatus) { $statusLabel.Text = $launcherStatus }
    } catch {}
  }

  if ((Test-Path $updateReadyFlag) -and
      ($null -eq $serviceProcess -or $serviceProcess.HasExited)) {
    Remove-Item -Force -ErrorAction SilentlyContinue $updateReadyFlag, $updateProgressFlag, $updateErrorFile
    $script:serviceProcess = $null
    $script:serviceReady = $false
    $script:browserOpened = $true
    $statusLabel.Text = "Обновление готово. Запускаем программу..."
    Start-ServiceProcess
    return
  }

  if ((Test-Path $updateErrorFile) -and
      ($null -eq $serviceProcess -or $serviceProcess.HasExited)) {
    try {
      $statusLabel.Text = [System.IO.File]::ReadAllText($updateErrorFile, [System.Text.Encoding]::UTF8)
    } catch {
      $statusLabel.Text = "Не удалось установить обновление. Старые файлы восстановлены."
    }
    Remove-Item -Force -ErrorAction SilentlyContinue $updateProgressFlag
    $healthTimer.Stop()
    $stopButton.Enabled = $false
    return
  }

  if ($null -ne $serviceProcess -and $serviceProcess.HasExited) {
    if (Test-Path $updateProgressFlag) {
      $updateAge = (Get-Date) - (Get-Item $updateProgressFlag).LastWriteTime
      if ($updateAge.TotalMinutes -gt 15) {
        Remove-Item -Force -ErrorAction SilentlyContinue $updateProgressFlag
        $statusLabel.Text = "Обновление прервалось. Запустите программу ещё раз."
        $healthTimer.Stop()
        return
      }
      $statusLabel.Text = "Устанавливаем обновление. Не закрывайте это окно..."
      $stopButton.Enabled = $false
      return
    }
    $healthTimer.Stop()
    $openButton.Enabled = $false
    $stopButton.Enabled = $false
    if (-not $statusLabel.Text.StartsWith("Ошибка запуска:")) {
      $statusLabel.Text = "Не удалось запустить программу. Проверьте интернет и повторите попытку."
    }
    return
  }

  if (-not $serviceReady -and (Test-ServiceReady)) {
    $script:serviceReady = $true
    $statusLabel.Text = "Программа запущена. Можно работать."
    $openButton.Enabled = $true
    if (-not $browserOpened) {
      $script:browserOpened = $true
      Start-Process $serviceUrl
    }
  }
})

$openButton.Add_Click({ Start-Process $serviceUrl })
$stopButton.Add_Click({ Stop-ServiceProcess })
$closeButton.Add_Click({ $form.Close() })
$form.Add_FormClosing({ Stop-ServiceProcess })
$form.Add_Shown({ Start-ServiceProcess })

[void]$form.ShowDialog()
