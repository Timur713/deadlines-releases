﻿param(
  [Parameter(Mandatory = $true)][string]$AppRoot,
  [Parameter(Mandatory = $true)][int]$ServerProcessId,
  [Parameter(Mandatory = $true)][string]$ManifestUrl
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$runtimeDir = Join-Path $AppRoot ".runtime"
$workDir = Join-Path $runtimeDir "update-work"
$statusFile = Join-Path $runtimeDir "windows-status.txt"
$progressFlag = Join-Path $runtimeDir "update-in-progress.flag"
$readyFlag = Join-Path $runtimeDir "update-ready.flag"
$errorFile = Join-Path $runtimeDir "update-error.txt"
$replacementStarted = $false
$managedPaths = @(
  "public",
  "src",
  "scripts",
  "node_modules",
  "bundled-dependencies.sha256",
  "package.json",
  "package-lock.json",
  "README.md",
  "release-info.json",
  "update-config.json",
  "задачи сотрудников.bat"
)

function Set-UpdateStatus([string]$message) {
  [System.IO.File]::WriteAllText($statusFile, $message, [System.Text.Encoding]::UTF8)
}

function Copy-ManagedFiles([string]$sourceRoot, [string]$destinationRoot) {
  foreach ($relativePath in $managedPaths) {
    $source = Join-Path $sourceRoot $relativePath
    if (-not (Test-Path $source)) { continue }
    $destination = Join-Path $destinationRoot $relativePath
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destination) | Out-Null
    Copy-Item -Recurse -Force -Path $source -Destination $destination
  }
}

try {
  New-Item -ItemType Directory -Force -Path $runtimeDir | Out-Null
  Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $workDir
  New-Item -ItemType Directory -Force -Path $workDir | Out-Null

  $manifestUri = [Uri]$ManifestUrl
  if ($manifestUri.Scheme -ne "https") {
    throw "Адрес обновления должен использовать HTTPS."
  }
  $headers = @{
    "User-Agent" = "employee-deadlines-updater"
    "Cache-Control" = "no-cache"
  }
  Set-UpdateStatus "Обновление: скачиваем описание версии..."
  $manifestPath = Join-Path $workDir "update.json"
  Invoke-WebRequest -UseBasicParsing -Headers $headers -Uri $ManifestUrl -OutFile $manifestPath
  $manifest = Get-Content -Raw -Encoding UTF8 $manifestPath | ConvertFrom-Json
  if (-not ($manifest.version -match "^\d+\.\d+\.\d+")) {
    throw "Сервер обновлений вернул некорректную версию."
  }
  if (-not ($manifest.sha256 -match "^[a-fA-F0-9]{64}$")) {
    throw "Сервер обновлений не передал контрольную сумму."
  }
  $downloadUri = [Uri]$manifest.downloadUrl
  if ($downloadUri.Scheme -ne "https") {
    throw "Адрес архива обновления должен использовать HTTPS."
  }

  Set-UpdateStatus "Обновление: скачиваем новую версию..."
  $archivePath = Join-Path $workDir "update.zip"
  Invoke-WebRequest -UseBasicParsing -Headers $headers -Uri $manifest.downloadUrl -OutFile $archivePath
  $actualHash = (Get-FileHash -Algorithm SHA256 -Path $archivePath).Hash
  if ($actualHash -ne $manifest.sha256.ToUpperInvariant()) {
    throw "Контрольная сумма обновления не совпала. Файлы не изменены."
  }

  Set-UpdateStatus "Обновление: проверяем файлы..."
  $extractDir = Join-Path $workDir "extracted"
  Expand-Archive -Path $archivePath -DestinationPath $extractDir -Force
  $newRoot = if (Test-Path (Join-Path $extractDir "package.json")) {
    $extractDir
  } else {
    Get-ChildItem -Directory $extractDir | Where-Object {
      Test-Path (Join-Path $_.FullName "package.json")
    } | Select-Object -First 1 -ExpandProperty FullName
  }
  if (-not $newRoot -or -not (Test-Path (Join-Path $newRoot "src\server.js")) -or
      -not (Test-Path (Join-Path $newRoot "scripts\windows-launcher.ps1"))) {
    throw "Архив обновления не содержит программу."
  }

  Set-UpdateStatus "Обновление: останавливаем программу..."
  Wait-Process -Id $ServerProcessId -ErrorAction SilentlyContinue

  $backupDir = Join-Path $workDir "backup"
  New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
  Copy-ManagedFiles $AppRoot $backupDir
  $replacementStarted = $true

  Set-UpdateStatus "Обновление: устанавливаем новую версию..."
  foreach ($relativePath in $managedPaths) {
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue (Join-Path $AppRoot $relativePath)
  }
  Copy-ManagedFiles $newRoot $AppRoot
  $newPackageLock = Join-Path $AppRoot "package-lock.json"
  if (Test-Path $newPackageLock) {
    $dependencyHash = (Get-FileHash -Algorithm SHA256 -Path $newPackageLock).Hash
    [System.IO.File]::WriteAllText(
      (Join-Path $runtimeDir "dependencies.sha256"),
      $dependencyHash
    )
  }
  Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path $AppRoot "start-windows.bat")
  Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path $AppRoot "ЗАПУСТИТЬ ПРОГРАММУ.bat")

  Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $workDir
  [System.IO.File]::WriteAllText($readyFlag, $manifest.version)
  Set-UpdateStatus "Обновление установлено. Перезапускаем программу..."
} catch {
  if ($replacementStarted) {
    try {
      foreach ($relativePath in $managedPaths) {
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue (Join-Path $AppRoot $relativePath)
      }
      Copy-ManagedFiles (Join-Path $workDir "backup") $AppRoot
    } catch {}
  }
  $message = "Ошибка обновления: $($_.Exception.Message)"
  [System.IO.File]::WriteAllText($errorFile, $message, [System.Text.Encoding]::UTF8)
  Set-UpdateStatus $message
  exit 1
}
