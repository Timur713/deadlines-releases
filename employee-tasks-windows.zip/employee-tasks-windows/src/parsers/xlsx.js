import fs from "node:fs/promises";
import path from "node:path";
import AdmZip from "adm-zip";
import { XMLParser } from "fast-xml-parser";
import { normalizeKey, normalizeText, sha256 } from "../utils.js";
import { parsePeriod } from "./dates.js";

const xmlParser = new XMLParser({
  ignoreAttributes: false,
  removeNSPrefix: true,
  textNodeName: "#text",
  parseTagValue: false,
  trimValues: false
});

export async function parseXlsx(filePath) {
  const stat = await fs.stat(filePath);
  const zip = new AdmZip(filePath);
  const sharedStrings = readSharedStrings(zip);
  const sheets = readWorkbookSheets(zip, sharedStrings);
  const candidates = sheets.flatMap((sheet) => findTaskTables(sheet, filePath));
  const selected = candidates.sort((a, b) => b.score - a.score)[0];

  if (!selected?.tasks.length) {
    return {
      file: fileRecord(filePath, stat),
      tasks: [],
      errors: [{ sourcePath: filePath, message: "Основная таблица задач не найдена" }]
    };
  }

  return {
    file: fileRecord(filePath, stat),
    tasks: selected.tasks,
    errors: selected.tasks
      .filter((task) => !task.deadlineRaw)
      .map((task) => ({
        sourcePath: filePath,
        employeeName: task.employeeName,
        taskNo: task.taskNo,
        field: "deadline",
        value: "",
        message: "Срок выполнения не заполнен"
      }))
  };
}

function fileRecord(filePath, stat) {
  return {
    path: filePath,
    mtimeMs: stat.mtimeMs,
    size: stat.size,
    hash: sha256(`${filePath}:${stat.mtimeMs}:${stat.size}`)
  };
}

function extractEmployee(rows, filePath, headerIndex) {
  const headingRows = rows.slice(0, headerIndex);
  const clean = headingRows.flat().map(normalizeText).filter(Boolean);
  const periodLine = clean.find((line) => normalizeKey(line).includes("на период")) || "";
  const period = parsePeriod(periodLine);

  return {
    employeeName: valueAboveLabel(headingRows, "фио") || fallbackName(filePath),
    employeePosition: valueAboveLabel(headingRows, "должность") || "",
    probationStart: period.start,
    probationEnd: period.end
  };
}

function valueAboveLabel(rows, label) {
  for (let rowIndex = 0; rowIndex < rows.length; rowIndex += 1) {
    for (let columnIndex = 0; columnIndex < rows[rowIndex].length; columnIndex += 1) {
      if (normalizeKey(rows[rowIndex][columnIndex]) !== label) continue;
      const inlineCandidate = normalizeText(rows[rowIndex][columnIndex - 1]);
      if (inlineCandidate && !isHeadingLabel(inlineCandidate)) return inlineCandidate;
      for (let offset = 1; offset <= 3; offset += 1) {
        const candidate = normalizeText(rows[rowIndex - offset]?.[columnIndex]);
        if (candidate && !isHeadingLabel(candidate)) return candidate;
      }
    }
  }
  return "";
}

function isHeadingLabel(value) {
  const key = normalizeKey(value);
  return key === "фио" || key === "должность" || key.includes("утверждаю");
}

function findTaskTables(sheet, filePath) {
  const { rows } = sheet;
  const headerIndex = rows.findIndex((row) => {
    const joined = normalizeKey(row.join(" "));
    return joined.includes("задачи") && joined.includes("результат") && joined.includes("срок выполнения");
  });
  if (headerIndex < 0) return [];

  const columns = detectColumns(rows[headerIndex]);
  if (!columns) return [];
  const employee = extractEmployee(rows, filePath, headerIndex);

  const data = [];
  for (const row of rows.slice(headerIndex + 1)) {
    const joined = normalizeKey(row.join(" "));
    if (joined.includes("сотрудник:") || joined.includes("инструкция по заполнению")) break;
    data.push(row);
  }

  const tasks = normalizeTaskRows(data, columns, employee, filePath, sheet.date1904);
  const datedTasks = tasks.filter((task) => task.deadlineRaw).length;
  const resultTasks = tasks.filter((task) => task.expectedResult).length;
  return [{
    sheetName: sheet.name,
    tasks,
    score: datedTasks * 1000 + tasks.length * 100 + resultTasks
  }];
}

function detectColumns(header) {
  const keys = Array.from({ length: header.length }, (_value, index) => normalizeKey(header[index]));
  const priority = keys.findIndex((key) => key.includes("приоритет"));
  const taskText = keys.findIndex((key) => key === "задачи" || key === "задача");
  const expectedResult = keys.findIndex((key) => key.includes("результат"));
  const deadline = keys.findIndex((key) => key.includes("срок выполнения"));
  if ([priority, taskText, expectedResult, deadline].some((index) => index < 0)) return null;
  return {
    priority,
    taskNo: taskText - 1,
    taskText,
    resultNo: expectedResult - 1,
    expectedResult,
    deadline
  };
}

function normalizeTaskRows(rows, columns, employee, sourcePath, date1904) {
  let lastPriority = "";
  let currentTask = null;
  const tasks = [];

  for (const row of rows) {
    const cells = Array.from({ length: row.length }, (_value, index) => normalizeText(row[index]));
    if (!cells.some(Boolean)) continue;
    const mapped = {
      priority: cells[columns.priority] || "",
      taskNo: normalizeCode(cells[columns.taskNo]),
      taskText: cells[columns.taskText] || "",
      resultNo: normalizeCode(cells[columns.resultNo]),
      expectedResult: cells[columns.expectedResult] || "",
      deadlineRaw: normalizeDeadline(cells[columns.deadline], date1904)
    };

    if (mapped.priority) lastPriority = mapped.priority;
    if (mapped.taskNo && mapped.taskText && !isPlaceholderTask(mapped.taskText)) {
      const task = {
        ...employee,
        sourcePath,
        priority: mapped.priority || lastPriority,
        taskNo: mapped.taskNo,
        taskText: mapped.taskText,
        resultNo: mapped.resultNo,
        expectedResult: mapped.expectedResult,
        deadlineRaw: mapped.deadlineRaw
      };
      task.taskId = sha256(`${sourcePath}|${employee.employeeName}|${task.taskNo}|${task.taskText}`);
      tasks.push(task);
      currentTask = task;
      continue;
    }

    if (currentTask && mapped.resultNo && mapped.expectedResult) {
      currentTask.expectedResult = [currentTask.expectedResult, mapped.expectedResult].filter(Boolean).join("; ");
      currentTask.resultNo = [currentTask.resultNo, mapped.resultNo].filter(Boolean).join(", ");
      currentTask.deadlineRaw = [currentTask.deadlineRaw, mapped.deadlineRaw].filter(Boolean).join("; ");
    }
  }
  return tasks;
}

function normalizeCode(value) {
  const match = String(value || "").match(/^\s*(\d+(?:\.\d+)+)\.?\s*$/);
  return match?.[1] || "";
}

function isPlaceholderTask(value) {
  return /^задача\s*№?\s*\d+\s+в\s+рамках\s+приоритета/iu.test(normalizeText(value));
}

function normalizeDeadline(value, date1904) {
  const text = normalizeText(value);
  if (!/^\d+(?:\.\d+)?$/.test(text)) return text;
  const serial = Number(text);
  if (!Number.isFinite(serial) || serial < 20_000 || serial > 80_000) return text;
  const epoch = date1904 ? Date.UTC(1904, 0, 1) : Date.UTC(1899, 11, 30);
  const date = new Date(epoch + Math.floor(serial) * 86_400_000);
  return [
    String(date.getUTCDate()).padStart(2, "0"),
    String(date.getUTCMonth() + 1).padStart(2, "0"),
    date.getUTCFullYear()
  ].join(".");
}

function fallbackName(filePath) {
  return filePath.split(/[\\/]/).pop()
    ?.replace(/\.(docx|xlsx)$/i, "")
    .replace(/_/g, " ")
    .replace(/^(?:шаблон\s*)?(?:задачи(?:\s+и\s+отчет)?(?:\s+вшб)?|задачи\s+и\s+отчет\s+вшб)\s*/iu, "")
    .replace(/\s+new$/iu, "")
    .trim() || "Без имени";
}

function readSharedStrings(zip) {
  const entry = zip.getEntry("xl/sharedStrings.xml");
  if (!entry) return [];
  const parsed = xmlParser.parse(entry.getData().toString("utf8"));
  return asArray(parsed?.sst?.si).map((item) => normalizeText(collectText(item).join(" ")));
}

function readWorkbookSheets(zip, sharedStrings) {
  const workbook = readXml(zip, "xl/workbook.xml");
  const rels = readXml(zip, "xl/_rels/workbook.xml.rels");
  const date1904 = ["1", "true"].includes(String(workbook?.workbook?.workbookPr?.["@_date1904"] || "").toLowerCase());
  const relMap = new Map(asArray(rels?.Relationships?.Relationship).map((rel) => [
    rel["@_Id"],
    rel["@_Target"]
  ]));

  return asArray(workbook?.workbook?.sheets?.sheet).flatMap((sheet) => {
    const relId = sheet["@_id"] || sheet["@_r:id"];
    const target = relMap.get(relId);
    if (!target) return [];
    const sheetPath = target.startsWith("/")
      ? target.slice(1)
      : path.posix.normalize(`xl/${target}`);
    const sheetXml = readXml(zip, sheetPath);
    const rows = asArray(sheetXml?.worksheet?.sheetData?.row)
      .map((row) => rowToValues(row, sharedStrings))
      .filter((row) => row.some(Boolean));
    return [{ name: sheet["@_name"] || "", rows, date1904 }];
  });
}

function readXml(zip, entryPath) {
  const entry = zip.getEntry(entryPath);
  if (!entry) return {};
  return xmlParser.parse(entry.getData().toString("utf8"));
}

function rowToValues(row, sharedStrings) {
  const cells = asArray(row?.c);
  const values = [];
  for (const cell of cells) {
    const ref = cell["@_r"] || "";
    const colIndex = ref ? columnIndex(ref.replace(/\d+/g, "")) : values.length;
    values[colIndex] = cellValue(cell, sharedStrings);
  }
  return values.map((value) => normalizeText(value || ""));
}

function cellValue(cell, sharedStrings) {
  const type = cell["@_t"];
  if (type === "s") return sharedStrings[Number(textValue(cell?.v))] || "";
  if (type === "inlineStr") return collectText(cell?.is).join(" ");
  return textValue(cell?.v);
}

function textValue(value) {
  if (value == null) return "";
  if (typeof value === "object" && "#text" in value) return value["#text"];
  return String(value);
}

function columnIndex(col) {
  let index = 0;
  for (const char of col.toUpperCase()) {
    index = index * 26 + (char.charCodeAt(0) - 64);
  }
  return Math.max(0, index - 1);
}

function collectText(node) {
  const out = [];
  walk(node, out);
  return out;
}

function walk(node, out) {
  if (node == null) return;
  if (typeof node === "string" || typeof node === "number") {
    out.push(String(node));
    return;
  }
  if (Array.isArray(node)) {
    for (const item of node) walk(item, out);
    return;
  }
  if (typeof node === "object") {
    if (node.t) walk(node.t, out);
    if (node["#text"]) walk(node["#text"], out);
    for (const [key, value] of Object.entries(node)) {
      if (key === "t" || key === "#text" || key.startsWith("@_")) continue;
      walk(value, out);
    }
  }
}

function asArray(value) {
  if (value == null) return [];
  return Array.isArray(value) ? value : [value];
}
