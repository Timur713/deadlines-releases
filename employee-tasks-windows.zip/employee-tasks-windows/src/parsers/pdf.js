import { execFile } from "node:child_process";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";
import { elapsedMs, logInfo } from "../logger.js";
import { normalizeKey, normalizeText, sha256 } from "../utils.js";
import { parsePeriod } from "./dates.js";

const execFileAsync = promisify(execFile);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ocrSourcePath = path.resolve(__dirname, "..", "..", "scripts", "ocr_pdf.swift");
const ocrTessdataPath = path.resolve(__dirname, "..", "..", "scripts", "tessdata");
const ocrCacheDir = path.join(os.tmpdir(), "hr-deadlines-ocr");
const ocrBinaryPath = path.join(ocrCacheDir, "ocr_pdf");
let compilePromise = null;

export async function parsePdf(filePath) {
  const stat = await fs.stat(filePath);
  const pages = await recognizePdf(filePath);
  const allItems = pages.flatMap((page) => prepareItems(page.items));
  const employee = extractEmployee(allItems, filePath);
  const tasks = [];
  const errors = [];

  for (const page of pages) {
    const result = parseTaskTable(prepareItems(page.items), employee, filePath);
    if (result.regions.length && process.env.PDF_CELL_OCR !== "0") {
      const cells = await recognizePdfRegions(filePath, page.page, page.orientation, result.regions);
      applyRecognizedCells(result.tasks, cells, filePath);
    }
    tasks.push(...result.tasks);
    errors.push(...result.errors);
  }

  normalizeRecurringDeadlines(tasks);
  correctEmployeePeriod(employee, allItems, tasks);
  for (const task of tasks) {
    task.probationStart = employee.probationStart;
    task.probationEnd = employee.probationEnd;
  }

  if (!tasks.length && !errors.length) {
    errors.push({ sourcePath: filePath, message: "Основная таблица задач в PDF не найдена" });
  }

  return {
    file: fileRecord(filePath, stat),
    tasks,
    errors
  };
}

async function recognizePdf(filePath) {
  if (process.platform !== "darwin") {
    throw new Error("OCR для PDF сейчас поддерживается на macOS");
  }
  await ensureOcrBinary();
  const startedAt = performance.now();
  logInfo("ocr", "Распознавание PDF начато", { file: path.basename(filePath) });
  const { stdout } = await execFileAsync(ocrBinaryPath, [filePath], {
    timeout: 240_000,
    maxBuffer: 50 * 1024 * 1024,
    env: { ...process.env, OCR_TESSDATA_PATH: ocrTessdataPath }
  });
  const pages = JSON.parse(stdout);
  logInfo("ocr", "Распознавание PDF завершено", {
    file: path.basename(filePath),
    pages: pages.length,
    durationMs: elapsedMs(startedAt)
  });
  return pages;
}

async function recognizePdfRegions(filePath, page, orientation, regions) {
  const startedAt = performance.now();
  logInfo("ocr", "Распознавание ячеек начато", {
    file: path.basename(filePath),
    page,
    cells: regions.length
  });
  const payload = Buffer.from(JSON.stringify([{ page, orientation, regions }]), "utf8").toString("base64");
  const { stdout } = await execFileAsync(ocrBinaryPath, [filePath, "--regions", payload], {
    timeout: 240_000,
    maxBuffer: 50 * 1024 * 1024,
    env: { ...process.env, OCR_TESSDATA_PATH: ocrTessdataPath }
  });
  const cells = JSON.parse(stdout);
  logInfo("ocr", "Распознавание ячеек завершено", {
    file: path.basename(filePath),
    page,
    cells: cells.length,
    durationMs: elapsedMs(startedAt)
  });
  return cells;
}

async function ensureOcrBinary() {
  if (!compilePromise) compilePromise = compileOcrBinaryIfNeeded();
  return compilePromise;
}

async function compileOcrBinaryIfNeeded() {
  await fs.mkdir(ocrCacheDir, { recursive: true });
  const [sourceStat, binaryStat] = await Promise.all([
    fs.stat(ocrSourcePath),
    fs.stat(ocrBinaryPath).catch(() => null)
  ]);
  if (binaryStat && binaryStat.mtimeMs >= sourceStat.mtimeMs) {
    logInfo("ocr", "OCR-модуль готов");
    return;
  }

  const startedAt = performance.now();
  logInfo("ocr", "Компиляция OCR-модуля начата");
  await execFileAsync("xcrun", ["swiftc", "-O", ocrSourcePath, "-o", ocrBinaryPath], {
    timeout: 120_000,
    maxBuffer: 10 * 1024 * 1024
  });
  logInfo("ocr", "Компиляция OCR-модуля завершена", { durationMs: elapsedMs(startedAt) });
}

function parseTaskTable(items, employee, sourcePath) {
  const headers = findHeaders(items);
  if (!headers) return { tasks: [], errors: [], regions: [] };

  const columnDirection = headers.deadline.centerX >= headers.task.centerX ? 1 : -1;
  const withU = items.map((item) => ({
    ...item,
    u: columnDirection > 0 ? item.centerX : 1 - item.centerX
  }));
  const taskHeaderU = projectX(headers.task, columnDirection);
  const resultHeaderU = projectX(headers.result, columnDirection);
  const deadlineHeaderU = projectX(headers.deadline, columnDirection);
  const headerY = median([headers.task.centerY, headers.result.centerY, headers.deadline.centerY]);

  const tableCodes = withU.filter((item) => {
    if (!normalizeCode(item.text)) return false;
    return item.u > taskHeaderU - 0.25 && item.u < resultHeaderU + 0.08 && Math.abs(item.centerY - headerY) > 0.025;
  });
  const dateItems = withU.filter((item) => {
    return looksLikeDate(item.text) && item.u > (resultHeaderU + deadlineHeaderU) / 2;
  });
  const rowSignals = [...tableCodes, ...dateItems];
  if (!rowSignals.length) {
    return {
      tasks: [],
      errors: [{ sourcePath, message: "В PDF найдена таблица, но не найдены строки с датами" }],
      regions: []
    };
  }

  const above = rowSignals.filter((item) => item.centerY > headerY).length;
  const rowDirection = above > rowSignals.length / 2 ? 1 : -1;
  const transformed = withU.map((item) => ({
    ...item,
    v: rowDirection > 0 ? item.centerY : 1 - item.centerY
  }));
  const headerV = rowDirection > 0 ? headerY : 1 - headerY;
  const codeColumns = findCodeColumns(transformed, headerV, taskHeaderU, resultHeaderU);
  if (codeColumns.length < 2) {
    return {
      tasks: [],
      errors: [{ sourcePath, message: "В PDF не удалось определить колонки номеров задач" }],
      regions: []
    };
  }

  const [taskNoU, resultNoU] = codeColumns.slice(0, 2);
  const deadlineStart = (resultHeaderU + deadlineHeaderU) / 2;
  const tableSignals = transformed.filter((item) => {
    if (item.v <= headerV + 0.01) return false;
    const code = normalizeCode(item.text);
    const codeSignal = code && (Math.abs(item.u - taskNoU) < 0.035 || Math.abs(item.u - resultNoU) < 0.035);
    const dateSignal = looksLikeDate(item.text) && item.u >= deadlineStart;
    return codeSignal || dateSignal;
  });
  const rowCenters = clusterValues(tableSignals.map((item) => item.v), 0.009);
  debugPdf(path.basename(sourcePath), {
    headers: { taskHeaderU, resultHeaderU, deadlineHeaderU, headerV },
    codeColumns,
    rowCenters,
    signals: tableSignals.map((item) => ({ text: item.text, u: item.u, v: item.v }))
  });
  if (!rowCenters.length) return { tasks: [], errors: [], regions: [] };

  const parsedRows = rowCenters.map((center, index) => {
    const previous = rowCenters[index - 1];
    const next = rowCenters[index + 1];
    const top = previous == null
      ? (next != null ? center - (next - center) * 0.62 : headerV + 0.01)
      : (previous + center) / 2;
    const bottom = next == null ? center + typicalGap(rowCenters) / 2 : (center + next) / 2;
    const primaryRowItems = transformed.filter((item) => item.v >= top && item.v < bottom);
    const rowItems = primaryRowItems;
    const taskNoItem = nearestCode(rowItems, taskNoU);
    const resultNoItem = nearestCode(rowItems, resultNoU);
    const inferredTaskNo = deriveTaskNumber(resultNoItem?.text);
    const resultNo = normalizeTaskNumber(resultNoItem?.text);
    const taskText = normalizeTaskCell(joinCell(rowItems.filter((item) => item.u > taskNoU + 0.015 && item.u < resultNoU - 0.012)));
    const expectedResult = normalizeResultCell(joinCell(rowItems.filter((item) => item.u > resultNoU + 0.012 && item.u < deadlineStart)));
    const taskNo = normalizeTaskNumber(taskNoItem?.text) || inferredTaskNo || resultNo || inferTaskNumber(taskText);
    const deadlineRaw = normalizePdfDeadline(joinCell(rowItems.filter((item) => item.u >= deadlineStart)));
    const regionPrefix = `${index}`;
    const regions = {
      taskNo: `${regionPrefix}:taskNo`,
      taskText: `${regionPrefix}:taskText`,
      resultNo: `${regionPrefix}:resultNo`,
      expectedResult: `${regionPrefix}:expectedResult`,
      deadlineRaw: `${regionPrefix}:deadlineRaw`
    };
    const ocrRegions = [
      createRegion(regions.taskText, taskNoU + 0.012, resultNoU - 0.012, top, bottom, columnDirection, rowDirection),
      createRegion(regions.expectedResult, resultNoU + 0.012, deadlineStart, top, bottom, columnDirection, rowDirection)
    ];

    debugPdf("row", { center, taskNo, resultNo, taskText, expectedResult, deadlineRaw });
    return { taskNo, resultNo, taskText, expectedResult, deadlineRaw, index, regions, ocrRegions };
  });

  for (let index = 0; index < parsedRows.length; index += 1) {
    const row = parsedRows[index];
    if (!row.deadlineRaw || row.taskNo || row.taskText) continue;
    const previous = parsedRows.slice(0, index).reverse().find((candidate) => {
      return (candidate.taskNo || candidate.taskText) && !looksLikeDate(candidate.deadlineRaw);
    });
    if (previous) {
      previous.deadlineRaw = [previous.deadlineRaw, row.deadlineRaw].filter(Boolean).join("; ");
      row.merged = true;
    }
  }

  const tasks = parsedRows.flatMap((row) => {
    if (row.merged || !row.deadlineRaw || (!row.taskText && !row.taskNo)) return [];
    const task = {
      ...employee,
      sourcePath,
      priority: "",
      taskNo: row.taskNo,
      taskText: row.taskText || `Задача ${row.taskNo || row.resultNo || row.index + 1}`,
      resultNo: row.resultNo,
      expectedResult: row.expectedResult,
      deadlineRaw: row.deadlineRaw
    };
    task._ocrRegions = row.regions;
    task.taskId = sha256(`${sourcePath}|${employee.employeeName}|${task.taskNo}|${task.taskText}`);
    return [task];
  });

  return {
    tasks,
    errors: [],
    regions: parsedRows.filter((row) => !row.merged).flatMap((row) => row.ocrRegions)
  };
}

function createRegion(id, u1, u2, v1, v2, columnDirection, rowDirection) {
  const x1 = columnDirection > 0 ? u1 : 1 - u2;
  const x2 = columnDirection > 0 ? u2 : 1 - u1;
  const y1 = rowDirection > 0 ? v1 : 1 - v2;
  const y2 = rowDirection > 0 ? v2 : 1 - v1;
  const minX = clamp(Math.min(x1, x2), 0, 1);
  const maxX = clamp(Math.max(x1, x2), 0, 1);
  const minY = clamp(Math.min(y1, y2), 0, 1);
  const maxY = clamp(Math.max(y1, y2), 0, 1);
  return { id, x: minX, y: minY, width: maxX - minX, height: maxY - minY };
}

function clamp(value, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, value));
}

function applyRecognizedCells(tasks, cells, sourcePath) {
  const byId = new Map(cells.map((cell) => [cell.id, {
    text: normalizeText(cell.text),
    confidence: Number(cell.confidence) || 0
  }]));
  for (const task of tasks) {
    const ids = task._ocrRegions || {};
    const taskNo = normalizeTaskNumber(byId.get(ids.taskNo)?.text);
    const resultNo = normalizeTaskNumber(byId.get(ids.resultNo)?.text);
    const taskText = normalizeTaskCell(byId.get(ids.taskText)?.text);
    const expectedResult = normalizeResultCell(byId.get(ids.expectedResult)?.text);
    const deadlineRaw = normalizePdfDeadline(byId.get(ids.deadlineRaw)?.text);

    debugPdf("cell", {
      taskNo: task.taskNo,
      originalTaskText: task.taskText,
      taskText,
      originalExpectedResult: task.expectedResult,
      expectedResult
    });

    if (!task.taskNo && taskNo) task.taskNo = taskNo;
    if (!task.resultNo && resultNo) task.resultNo = resultNo;
    task.taskText = normalizeTaskCell(chooseCompleteText(task.taskText, taskText));
    task.expectedResult = normalizeResultCell(chooseCompleteText(task.expectedResult, expectedResult));
    task.deadlineRaw = chooseDeadline(task.deadlineRaw, deadlineRaw);
    task.taskId = sha256(`${sourcePath}|${task.employeeName}|${task.taskNo}|${task.taskText}`);
    delete task._ocrRegions;
  }
}

function chooseCompleteText(original, candidate) {
  if (!candidate) return original;
  if (!original) return candidate;
  const reorderedCandidate = matchInitialCase(reorderWrappedText(candidate, original), original);
  const repairedReorderedCandidate = restoreTruncatedWords(reorderedCandidate, original);
  const complementedCandidate = mergeComplementaryText(repairedReorderedCandidate, original);
  const repairedCandidate = restoreTruncatedWords(complementedCandidate, original);
  const originalWords = original.split(/\s+/).length;
  const candidateWords = repairedCandidate.split(/\s+/).length;
  if (startsUppercase(repairedCandidate) && !startsUppercase(original) && candidateWords >= originalWords) {
    return repairedCandidate;
  }
  return candidateWords >= originalWords + Math.max(2, Math.ceil(originalWords * 0.12)) ? repairedCandidate : original;
}

function mergeComplementaryText(candidate, original) {
  const candidateWords = candidate.split(/\s+/);
  const originalWords = original.split(/\s+/);
  const key = (word) => fold(word.replace(/[^\p{L}\p{N}]+/gu, ""));
  const candidateKeys = candidateWords.map(key);
  const originalKeys = originalWords.map(key);
  const originalCounts = new Map();
  const candidateCounts = new Map();
  for (const word of originalKeys) originalCounts.set(word, (originalCounts.get(word) || 0) + 1);
  for (const word of candidateKeys) candidateCounts.set(word, (candidateCounts.get(word) || 0) + 1);
  const extras = [...candidateCounts].reduce((sum, [word, count]) => sum + Math.max(0, count - (originalCounts.get(word) || 0)), 0);
  const missing = [...originalCounts].reduce((sum, [word, count]) => sum + Math.max(0, count - (candidateCounts.get(word) || 0)), 0);
  const overlap = originalKeys.filter((word) => candidateCounts.has(word)).length / Math.max(1, originalKeys.length);
  if (candidateWords.length < originalWords.length || candidateWords.length - originalWords.length < 1 || missing > 2 || overlap < 0.75) {
    return candidate;
  }

  const dp = Array.from({ length: originalWords.length + 1 }, () => Array(candidateWords.length + 1).fill(0));
  for (let i = originalWords.length - 1; i >= 0; i -= 1) {
    for (let j = candidateWords.length - 1; j >= 0; j -= 1) {
      dp[i][j] = originalKeys[i] === candidateKeys[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
  const merged = [];
  let i = 0;
  let j = 0;
  while (i < originalWords.length && j < candidateWords.length) {
    if (originalKeys[i] === candidateKeys[j]) {
      merged.push(candidateWords[j]);
      i += 1;
      j += 1;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      merged.push(originalWords[i]);
      i += 1;
    } else {
      merged.push(candidateWords[j]);
      j += 1;
    }
  }
  merged.push(...originalWords.slice(i), ...candidateWords.slice(j));
  return extras >= 1 ? merged.join(" ") : candidate;
}

function matchInitialCase(candidate, original) {
  if (!startsUppercase(original) || startsUppercase(candidate)) return candidate;
  return candidate.replace(/\p{L}/u, (letter) => letter.toLocaleUpperCase("ru-RU"));
}

function reorderWrappedText(candidate, original) {
  const candidateWords = candidate.split(/\s+/);
  const originalWords = original.split(/\s+/);
  const keys = (words) => words.map((word) => fold(word.replace(/[^\p{L}\p{N}]+/gu, "")));
  const candidateKeys = keys(candidateWords);
  const originalKeys = keys(originalWords);
  let prefixAtEnd = 0;
  let suffixAtStart = 0;

  for (let size = 2; size <= Math.min(originalKeys.length, candidateKeys.length); size += 1) {
    if (originalKeys.slice(0, size).join("|") === candidateKeys.slice(-size).join("|")) prefixAtEnd = size;
    if (originalKeys.slice(-size).join("|") === candidateKeys.slice(0, size).join("|")) suffixAtStart = size;
  }
  if (prefixAtEnd >= Math.max(2, Math.ceil(originalWords.length * 0.8)) && prefixAtEnd < candidateWords.length) {
    return [...candidateWords.slice(-prefixAtEnd), ...candidateWords.slice(0, -prefixAtEnd)].join(" ");
  }
  if (prefixAtEnd < 2 || suffixAtStart < 2 || prefixAtEnd + suffixAtStart > candidateWords.length) return candidate;
  return [
    ...candidateWords.slice(-prefixAtEnd),
    ...candidateWords.slice(suffixAtStart, candidateWords.length - prefixAtEnd),
    ...candidateWords.slice(0, suffixAtStart)
  ].join(" ");
}

function startsUppercase(value) {
  const first = String(value || "").match(/\p{L}/u)?.[0];
  return Boolean(first && first === first.toLocaleUpperCase("ru-RU") && first !== first.toLocaleLowerCase("ru-RU"));
}

function restoreTruncatedWords(candidate, original) {
  const originals = original.split(/\s+/).map((word) => word.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, ""));
  return candidate.split(/\s+/).map((word) => {
    const bare = word.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "");
    if (bare.length < 4) return word;
    const matches = originals.filter((source) => source.length > bare.length && fold(source).startsWith(fold(bare)));
    if (matches.length !== 1) return word;
    return word.replace(bare, matches[0]);
  }).join(" ");
}

function chooseDeadline(original, candidate) {
  if (!candidate) return original;
  if (!original) return candidate;
  const originalDates = extractValidDates(original).length;
  const candidateDates = extractValidDates(candidate).length;
  return candidateDates > originalDates ? candidate : original;
}

function findHeaders(items) {
  const exactTaskHeaders = items.filter((item) => normalizeKey(item.text) === "задачи");
  const taskHeaders = exactTaskHeaders.length
    ? exactTaskHeaders
    : items.filter((item) => normalizeKey(item.text).includes("индивидуальные задачи"));
  const resultHeaders = items.filter((item) => normalizeKey(item.text).includes("ожидаемые результаты"));
  const deadlineHeaders = items.filter((item) => {
    const key = normalizeKey(item.text);
    return key.includes("дата") || key.includes("срок выполн") || key.includes("рок выполн");
  });
  let best = null;

  for (const task of taskHeaders) {
    for (const result of resultHeaders) {
      for (const deadline of deadlineHeaders) {
        const xs = [task.centerX, result.centerX, deadline.centerX];
        const ys = [task.centerY, result.centerY, deadline.centerY];
        const xSpan = Math.max(...xs) - Math.min(...xs);
        const ySpan = Math.max(...ys) - Math.min(...ys);
        const resultBetween = between(result.centerX, task.centerX, deadline.centerX);
        const score = xSpan - ySpan * 4 + (resultBetween ? 0.5 : 0);
        if (!best || score > best.score) best = { task, result, deadline, score };
      }
    }
  }

  return best && best.score > 0.25 ? best : null;
}

function findCodeColumns(items, headerV, taskHeaderU, resultHeaderU) {
  const candidates = items.filter((item) => {
    if (!normalizeCode(item.text) || item.v <= headerV + 0.01) return false;
    return item.u > taskHeaderU - 0.25 && item.u < resultHeaderU + 0.08;
  });
  const clusters = [];
  for (const item of candidates.sort((a, b) => a.u - b.u)) {
    const current = clusters.at(-1);
    if (!current || Math.abs(item.u - median(current.map((entry) => entry.u))) > 0.035) {
      clusters.push([item]);
    } else {
      current.push(item);
    }
  }
  return clusters
    .filter((cluster) => cluster.length >= 2)
    .map((cluster) => ({ u: median(cluster.map((item) => item.u)), count: cluster.length }))
    .sort((a, b) => a.u - b.u)
    .slice(0, 2)
    .map((cluster) => cluster.u);
}

function extractEmployee(items, filePath) {
  const periodLine = items.find((item) => normalizeKey(item.text).includes("период"))?.text || "";
  const period = parsePeriod(periodLine);
  const fileTokens = cleanPdfFileName(filePath).split(/\s+/).map(fold).filter((token) => token.length >= 4);
  const employeeItem = items
    .filter((item) => fileTokens.some((token) => fold(item.text).includes(token)))
    .filter((item) => /^[А-ЯЁA-Z][а-яёa-z-]+(?:\s+[А-ЯЁA-ZНД][А-Яа-яЁёA-Za-z.-]*){1,3}$/u.test(item.text))
    .sort((a, b) => b.text.length - a.text.length)[0];

  return {
    employeeName: employeeItem?.text || cleanPdfFileName(filePath),
    employeePosition: extractPosition(items),
    probationStart: period.start,
    probationEnd: period.end
  };
}

function extractPosition(items) {
  for (let index = 1; index < items.length; index += 1) {
    if (normalizeKey(items[index].text) !== "должность") continue;
    const candidate = items[index - 1]?.text || "";
    if (candidate && !normalizeKey(candidate).includes("период")) return candidate;
  }
  return "";
}

function prepareItems(items = []) {
  return items.map((item) => ({
    ...item,
    text: normalizeText(item.text),
    centerX: Number(item.x) + Number(item.width) / 2,
    centerY: Number(item.y) + Number(item.height) / 2
  })).filter((item) => item.text);
}

function joinCell(items) {
  return items
    .filter((item) => !normalizeCode(item.text) || looksLikeDate(item.text))
    .filter((item) => {
      const key = normalizeKey(item.text);
      return key !== "дата" && key !== "задачи" && !key.includes("ожидаемые результаты") && !key.includes("срок выполн");
    })
    .sort((a, b) => Math.abs(a.v - b.v) > 0.004 ? a.v - b.v : a.u - b.u)
    .map((item) => item.text)
    .join(" ")
    .replace(/\s+/g, " ")
    .trim();
}

function nearestCode(items, targetU) {
  const candidate = items
    .filter((item) => normalizeCode(item.text))
    .sort((a, b) => Math.abs(a.u - targetU) - Math.abs(b.u - targetU))[0];
  return candidate && Math.abs(candidate.u - targetU) < 0.045 ? candidate : null;
}

function normalizeCode(value) {
  const text = String(value || "").replace(/\s+/g, "").replace(/,/g, ".");
  return /^\d+(?:\.\d+){1,2}$/.test(text) ? text : "";
}

function normalizeTaskNumber(value) {
  const code = normalizeCode(value);
  if (code) return code;
  const digits = String(value || "").replace(/\D/g, "");
  return digits.length === 2 ? `${digits[0]}.${digits[1]}` : "";
}

function deriveTaskNumber(value) {
  const code = normalizeCode(value);
  const parts = code.split(".");
  return parts.length >= 3 ? parts.slice(0, 2).join(".") : "";
}

function inferTaskNumber(taskText) {
  const text = String(taskText || "");
  const match = /задач\D{0,8}(\d+)\D+приоритет\D{0,8}(\d+)/i.exec(text);
  return match ? `${match[2]}.${match[1]}` : "";
}

function normalizePdfDeadline(value) {
  return String(value || "")
    .replace(/(\d{1,2}[.]\d{1,2})\s+(20\d{2})/g, "$1.$2")
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeTaskCell(value) {
  return normalizeCommonCell(value)
    .replace(/^.*?принцип[ау]?\s+SMART\s*/iu, "")
    .replace(/\bранках\b/giu, "рамках")
    .replace(/(приоритет\S*\s+№\d+)\s+(?=[А-ЯЁ])/u, "$1. ")
    .trim();
}

function normalizeResultCell(value) {
  return normalizeCommonCell(value)
    .replace(/^.*?вывод\s+о\s+выполн\S*\s+или\s+невыполн\S*\s+задач\S*\s*/iu, "")
    .replace(/^(?:выполн\S*\s+или\s+)?невыполн\S*\s+задач\S*\s*/iu, "")
    .replace(/^выполн\S*\s+задач\S*\s*/iu, "")
    .trim();
}

function normalizeCommonCell(value) {
  return String(value || "")
    .replace(/\bN[oº°]\s*(\d+)/giu, "№$1")
    .replace(/№\s+(\d+)/g, "№$1")
    .replace(/[,，]\s*(?=согласно(?!\p{L}))/giu, " ")
    .replace(/(?<!\p{L})([а-яё]{2,})([А-ЯЁ])(?!\p{L})/gu, (_, stem, last) => `${stem}${last.toLocaleLowerCase("ru-RU")}`)
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeRecurringDeadlines(tasks) {
  const recurring = tasks.filter((task) => {
    const key = fold(task.deadlineRaw);
    return key.includes("постоян") || key.includes("контрол");
  });
  const canonical = recurring
    .map((task) => ({ task, dates: extractValidDates(task.deadlineRaw) }))
    .sort((a, b) => b.dates.length - a.dates.length)[0];
  if (!canonical || canonical.dates.length < 2) return;

  const canonicalRaw = `контроль ${canonical.dates.join(", ")}`;
  for (const task of recurring) {
    if (extractValidDates(task.deadlineRaw).length < canonical.dates.length) task.deadlineRaw = canonicalRaw;
  }
}

function extractValidDates(value) {
  const dates = [];
  for (const match of String(value || "").matchAll(/(\d{1,2})[.](\d{1,2})[.](20\d{2})/g)) {
    const day = Number(match[1]);
    const month = Number(match[2]);
    const year = Number(match[3]);
    const date = new Date(year, month - 1, day);
    if (date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day) {
      dates.push(`${String(day).padStart(2, "0")}.${String(month).padStart(2, "0")}.${year}`);
    }
  }
  return [...new Set(dates)];
}

function looksLikeDate(value) {
  const text = String(value || "").toLowerCase();
  return /\d{1,2}[.]\d{1,2}[.]\d{4}/.test(text) ||
    /\d{1,2}\s+(января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)/.test(text);
}

function clusterValues(values, tolerance) {
  const clusters = [];
  for (const value of [...values].sort((a, b) => a - b)) {
    const current = clusters.at(-1);
    if (!current || Math.abs(value - median(current)) > tolerance) clusters.push([value]);
    else current.push(value);
  }
  return clusters.map(median);
}

function typicalGap(values) {
  const gaps = values.slice(1).map((value, index) => value - values[index]).filter((gap) => gap > 0.005);
  return median(gaps) || 0.04;
}

function projectX(item, direction) {
  return direction > 0 ? item.centerX : 1 - item.centerX;
}

function median(values) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

function between(value, first, second) {
  return value > Math.min(first, second) && value < Math.max(first, second);
}

export function cleanPdfFileName(filePath) {
  return path.basename(filePath)
    .replace(/\.(pdf|docx|xlsx)$/i, "")
    .replace(/(?:^|\s)план\s+задач(?=\s|$)/gi, " ")
    .replace(/(?:^|\s)задачи(?=\s|$)/gi, " ")
    .replace(/(?:^|\s)на\s+ис(?=\s|$)/gi, " ")
    .replace(/\s+/g, " ")
    .trim() || "Без имени";
}

function correctEmployeePeriod(employee, items, tasks) {
  const periodLine = items.find((item) => normalizeKey(item.text).includes("период"))?.text || "";
  const repaired = periodLine
    .replace(/(\d{1,2}[.]\d{1,2})\s+(\d{4})/g, "$1.$2")
    .replace(/\s+[пp]\s*(?=\d{1,2}[.])/gi, " по ")
    .replace(/п(?=\d{1,2}[.])/gi, " по ");
  const dateStart = repaired.search(/\d{1,2}[.]\d{1,2}[.]\d{4}/);
  const periodSource = dateStart >= 0 ? `с ${repaired.slice(dateStart)}` : repaired;
  const parsed = parsePeriod(periodSource);
  const years = tasks.flatMap((task) => [...String(task.deadlineRaw).matchAll(/20\d{2}/g)].map((match) => Number(match[0])));
  const commonYear = mode(years);

  if (parsed.start && parsed.end) {
    employee.probationStart = adjustYear(parsed.start, commonYear);
    employee.probationEnd = adjustYear(parsed.end, commonYear);
    const start = employee.probationStart?.split("-").map(Number);
    const end = employee.probationEnd?.split("-").map(Number);
    if (start && end && start[2] < 10 && end[2] >= 20 && start[2] === end[2] % 10) {
      employee.probationStart = `${start[0]}-${String(start[1]).padStart(2, "0")}-${String(end[2]).padStart(2, "0")}`;
    }
  }
}

function adjustYear(iso, preferredYear) {
  if (!iso || !preferredYear) return iso;
  const [year, month, day] = iso.split("-").map(Number);
  if (Math.abs(year - preferredYear) <= 1) return iso;
  return `${preferredYear}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

function mode(values) {
  const counts = new Map();
  for (const value of values) counts.set(value, (counts.get(value) || 0) + 1);
  return [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || null;
}

function fold(value) {
  return String(value || "").normalize("NFD").replace(/\p{M}/gu, "").toLowerCase().replace(/ё/g, "е");
}

function fileRecord(filePath, stat) {
  return {
    path: filePath,
    mtimeMs: stat.mtimeMs,
    size: stat.size,
    hash: sha256(`${filePath}:${stat.mtimeMs}:${stat.size}`)
  };
}

function debugPdf(...args) {
  if (process.env.DEBUG_PDF === "1") console.error(...args);
}
