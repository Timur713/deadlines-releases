import { addDays, parseIsoDate, toIsoDate } from "../utils.js";

const monthMap = new Map([
  ["января", 0], ["январь", 0],
  ["февраля", 1], ["февраль", 1],
  ["марта", 2], ["март", 2],
  ["апреля", 3], ["апрель", 3],
  ["мая", 4], ["май", 4],
  ["июня", 5], ["июнь", 5],
  ["июля", 6], ["июль", 6],
  ["августа", 7], ["август", 7],
  ["сентября", 8], ["сентябрь", 8],
  ["октября", 9], ["октябрь", 9],
  ["ноября", 10], ["ноябрь", 10],
  ["декабря", 11], ["декабрь", 11]
]);

export function parsePeriod(text) {
  const raw = String(text ?? "").toLowerCase().replace(/\u00a0/g, " ");

  const numericRange = raw.match(/с\s*(\d{1,2})\.(\d{1,2})\.(\d{4})\s*(?:по|-|–)\s*(\d{1,2})\.(\d{1,2})\.(\d{4})/);
  if (numericRange) {
    return {
      start: toIsoDate(new Date(Number(numericRange[3]), Number(numericRange[2]) - 1, Number(numericRange[1]))),
      end: toIsoDate(new Date(Number(numericRange[6]), Number(numericRange[5]) - 1, Number(numericRange[4])))
    };
  }

  const wordRange = raw.match(/с\s*(\d{1,2})\s+([а-яё]+)(?:\s+(\d{4}))?\s*(?:по|-|–)\s*(\d{1,2})\s+([а-яё]+)\s+(\d{4})/);
  if (wordRange && monthMap.has(wordRange[2]) && monthMap.has(wordRange[5])) {
    const endYear = Number(wordRange[6]);
    const startMonth = monthMap.get(wordRange[2]);
    const endMonth = monthMap.get(wordRange[5]);
    const startYear = wordRange[3] ? Number(wordRange[3]) : endYear - (startMonth > endMonth ? 1 : 0);
    return {
      start: validIsoDate(Number(wordRange[1]), startMonth + 1, startYear),
      end: validIsoDate(Number(wordRange[4]), endMonth + 1, endYear)
    };
  }

  return { start: null, end: null };
}

export function parseDeadlineEvents(task) {
  const raw = String(task.deadlineRaw ?? "").trim();
  const normalized = raw.toLowerCase().replace(/\u00a0/g, " ");
  const events = [];
  const errors = [];
  const seen = new Set();

  const pushDate = (iso, type) => {
    if (!iso || seen.has(`${iso}:${type}`)) return;
    seen.add(`${iso}:${type}`);
    events.push({ dueDate: iso, deadlineType: type, deadlineRaw: raw });
  };

  const periodStart = parseIsoDate(task.probationStart);
  const periodEnd = parseIsoDate(task.probationEnd);

  const ranges = [...normalized.matchAll(/(\d{1,2})\.(\d{1,2})\.(\d{4})\s*[-–]\s*(\d{1,2})\.(\d{1,2})\.(\d{4})/g)];
  const rangeSpans = [];
  for (const range of ranges) {
    rangeSpans.push([range.index, range.index + range[0].length]);
    pushDate(validIsoDate(Number(range[4]), Number(range[5]), Number(range[6])), "range_end");
  }

  const fullDates = [...normalized.matchAll(/(\d{1,2})\.(\d{1,2})\.(\d{4})/g)];
  const typeFromText = normalized.includes("контрол") ? "control" : normalized.includes("до ") ? "due" : "date";
  for (const match of fullDates) {
    if (rangeSpans.some(([start, end]) => match.index >= start && match.index < end)) continue;
    const iso = validIsoDate(Number(match[1]), Number(match[2]), Number(match[3]));
    pushDate(iso, typeFromText);
  }

  const wordDates = [...normalized.matchAll(/(?<!\d)(\d{1,2})\s+(января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)(?:\s+(\d{4}))?/g)];
  let wordDateMissingYear = false;
  for (const match of wordDates) {
    const day = Number(match[1]);
    const month = monthMap.get(match[2]);
    if (!match[3] && (!periodStart || !periodEnd)) {
      wordDateMissingYear = true;
      continue;
    }
    const year = match[3] ? Number(match[3]) : inferYear(day, month, periodStart, periodEnd);
    pushDate(validIsoDate(day, month + 1, year), normalized.includes("до ") ? "due" : "date");
  }

  if (normalized.includes("еженед") && periodStart && periodEnd) {
    for (let cursor = new Date(periodStart); cursor <= periodEnd; cursor = addDays(cursor, 7)) {
      pushDate(toIsoDate(cursor), "recurring_weekly");
    }
  }

  if (!events.length && raw) {
    errors.push({
      sourcePath: task.sourcePath,
      employeeName: task.employeeName,
      taskNo: task.taskNo,
      field: "deadline",
      value: raw,
      message: wordDateMissingYear
        ? "Для срока без года не заполнен период испытательного срока"
        : "Не удалось распознать срок"
    });
  }

  return { events, errors };
}

function inferYear(day, month, periodStart, periodEnd) {
  const fallbackYear = periodStart?.getFullYear() || new Date().getFullYear();
  if (!periodStart || !periodEnd) return fallbackYear;

  const candidates = [periodStart.getFullYear(), periodEnd.getFullYear(), fallbackYear - 1, fallbackYear + 1];
  for (const year of [...new Set(candidates)]) {
    const candidate = new Date(year, month, day);
    if (candidate >= periodStart && candidate <= periodEnd) return year;
  }
  return fallbackYear;
}

function validIsoDate(day, month, year) {
  if (!Number.isInteger(day) || !Number.isInteger(month) || !Number.isInteger(year)) return null;
  const date = new Date(year, month - 1, day);
  if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) return null;
  return toIsoDate(date);
}
