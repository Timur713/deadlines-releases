import fs from "node:fs/promises";
import AdmZip from "adm-zip";
import { XMLParser } from "fast-xml-parser";
import { compactMultiline, normalizeKey, normalizeText, sha256 } from "../utils.js";
import { parsePeriod } from "./dates.js";

const xmlParser = new XMLParser({
  ignoreAttributes: false,
  removeNSPrefix: true,
  textNodeName: "#text",
  parseTagValue: false,
  trimValues: false
});

export async function parseDocx(filePath) {
  const stat = await fs.stat(filePath);
  const zip = new AdmZip(filePath);
  const documentEntry = zip.getEntry("word/document.xml");
  if (!documentEntry) throw new Error("word/document.xml не найден");

  const xml = documentEntry.getData().toString("utf8");
  const parsed = xmlParser.parse(xml);
  const body = parsed?.document?.body;
  const tables = asArray(body?.tbl).map(tableToRows).filter((rows) => rows.length);
  const allText = collectText(body).map(normalizeText).filter(Boolean);
  const employee = extractEmployee(allText, filePath);
  const taskTable = findTaskTable(tables);

  if (!taskTable) {
    return {
      file: fileRecord(filePath, stat),
      tasks: [],
      errors: [{ sourcePath: filePath, message: "Основная таблица задач не найдена" }]
    };
  }

  return {
    file: fileRecord(filePath, stat),
    tasks: normalizeTaskRows(taskTable, employee, filePath),
    errors: []
  };
}

function fileRecord(filePath, stat) {
  return {
    path: filePath,
    mtimeMs: stat.mtimeMs,
    size: stat.size,
    hash: sha256(`${filePath}:${stat.mtimeMs}:${stat.size}`)
  };
}

function tableToRows(tbl) {
  return asArray(tbl?.tr).map((row) => asArray(row?.tc).map((cell) => normalizeText(collectText(cell).join(" "))));
}

function findTaskTable(tables) {
  return tables.find((rows) => rows.some((row) => {
    const joined = normalizeKey(row.join(" "));
    return joined.includes("задачи") && joined.includes("ожидаемые результаты") && joined.includes("срок выполнения");
  }));
}

function extractEmployee(lines, filePath) {
  const periodLineIndex = lines.findIndex((line) => normalizeKey(line).includes("задачи на период"));
  const periodLine = periodLineIndex >= 0 ? lines[periodLineIndex] : "";
  const period = parsePeriod(periodLine);
  const afterPeriod = lines.slice(periodLineIndex + 1, periodLineIndex + 8).filter(Boolean);

  const positionIndex = afterPeriod.findIndex((line) => normalizeKey(line) === "должность");
  const fioIndex = afterPeriod.findIndex((line) => normalizeKey(line) === "фио");
  const employeePosition = positionIndex > 0 ? afterPeriod[positionIndex - 1] : "";
  const employeeName = fioIndex > 0 ? afterPeriod[fioIndex - 1] : fallbackName(filePath);

  return {
    employeeName,
    employeePosition,
    probationStart: period.start,
    probationEnd: period.end
  };
}

function normalizeTaskRows(rows, employee, sourcePath) {
  const headerIndex = rows.findIndex((row) => normalizeKey(row.join(" ")).includes("срок выполнения"));
  const dataStart = Math.min(rows.length, headerIndex + 2);
  let lastPriority = "";
  const tasks = [];

  for (const row of rows.slice(dataStart)) {
    if (!row.some(Boolean)) continue;
    if (normalizeKey(row.join(" ")).includes("сотрудник:")) break;
    if (normalizeKey(row.join(" ")).includes("инструкция по заполнению")) break;

    const cells = normalizeTaskCells(row);
    if (!cells.taskText || !cells.deadlineRaw) continue;
    if (cells.priority) lastPriority = cells.priority;

    const task = {
      ...employee,
      sourcePath,
      priority: cells.priority || lastPriority,
      taskNo: cells.taskNo,
      taskText: cells.taskText,
      resultNo: cells.resultNo,
      expectedResult: cells.expectedResult,
      deadlineRaw: cells.deadlineRaw
    };
    task.taskId = sha256(`${sourcePath}|${employee.employeeName}|${task.taskNo}|${task.taskText}`);
    tasks.push(task);
  }

  return tasks;
}

function normalizeTaskCells(row) {
  const cells = [...row];
  if (cells.length >= 6) {
    return {
      priority: cells[0],
      taskNo: cells[1],
      taskText: cells[2],
      resultNo: cells[3],
      expectedResult: cells[4],
      deadlineRaw: cells[5]
    };
  }

  return {
    priority: cells[0] || "",
    taskNo: findNumber(cells),
    taskText: cells[1] || "",
    resultNo: "",
    expectedResult: cells[2] || "",
    deadlineRaw: cells[cells.length - 1] || ""
  };
}

function findNumber(cells) {
  return cells.find((cell) => /^\d+(?:\.\d+)*$/.test(cell)) || "";
}

function collectText(node) {
  const out = [];
  walk(node, out);
  return out;
}

function walk(node, out) {
  if (node == null) return;
  if (typeof node === "string" || typeof node === "number") {
    out.push(String(node));
    return;
  }
  if (Array.isArray(node)) {
    for (const item of node) walk(item, out);
    return;
  }
  if (typeof node === "object") {
    if (node.t) walk(node.t, out);
    if (node["#text"]) walk(node["#text"], out);
    for (const [key, value] of Object.entries(node)) {
      if (key === "t" || key === "#text" || key.startsWith("@_")) continue;
      walk(value, out);
    }
  }
}

function asArray(value) {
  if (value == null) return [];
  return Array.isArray(value) ? value : [value];
}

function fallbackName(filePath) {
  return filePath.split(/[\\/]/).pop()?.replace(/\.(docx|xlsx)$/i, "") || "Без имени";
}
