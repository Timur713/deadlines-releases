import express from "express";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import multer from "multer";
import { renderDocxPreview, renderUnsupportedPreview } from "./document-preview.js";
import { createDeadlineExport } from "./exporter.js";
import { elapsedMs, logError, logInfo } from "./logger.js";
import { sendSummaryEmail, sendTestEmail } from "./mailer.js";
import { buildSummary, buildSummaryFromEvents, scanPlans } from "./scanner.js";
import { addSentEvents, getCache, getSettings, saveSettings } from "./store.js";
import { restartScheduler } from "./scheduler.js";
import { splitEmails, todayIso } from "./utils.js";
import { getUpdateStatus, launchWindowsUpdate } from "./updater.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = Number(process.env.PORT || 3000);
const sourceFilesDir = path.join(__dirname, "..", "data", "source-files");
const allowedSourceExtensions = new Set([".docx", ".xlsx", ".pdf"]);
const sourceUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024, files: 50 },
  fileFilter: (_req, file, callback) => {
    callback(null, allowedSourceExtensions.has(path.extname(file.originalname).toLowerCase()));
  }
});

app.use(express.json({ limit: "1mb" }));
app.use((req, res, next) => {
  if (!req.path.startsWith("/api/")) return next();
  const startedAt = performance.now();
  res.on("finish", () => {
    logInfo("http", "Запрос завершён", {
      method: req.method,
      path: req.path,
      status: res.statusCode,
      durationMs: elapsedMs(startedAt)
    });
  });
  next();
});
app.use(express.static(path.join(__dirname, "..", "public")));

async function dailyRun(date = todayIso()) {
  logInfo("scheduler", "Ежедневная проверка начата", { date });
  const settings = await getSettings();
  const cache = await scanPlans(settings);
  const summary = buildSummary(cache, settings, date);
  if (!summary.totalEvents && !settings.sendEmptySummary) {
    logInfo("scheduler", "Задач для отправки нет", { date });
    return { sent: false, summary };
  }
  const info = await sendSummaryEmail(settings, summary);
  await addSentEvents(summary.groups.flatMap((group) => group.events), {
    emailTo: splitEmails(settings.hrRecipients),
    messageId: info.messageId
  });
  logInfo("scheduler", "Ежедневная проверка завершена", {
    date,
    events: summary.totalEvents,
    sent: true
  });
  return { sent: true, summary, messageId: info.messageId };
}

app.get("/api/settings", async (_req, res, next) => {
  try {
    res.json(await getSettings());
  } catch (error) {
    next(error);
  }
});

app.post("/api/settings", async (req, res, next) => {
  try {
    const settings = await saveSettings(req.body);
    restartScheduler(settings, dailyRun);
    res.json(settings);
  } catch (error) {
    next(error);
  }
});

app.post("/api/scan", async (_req, res, next) => {
  try {
    const settings = await getSettings();
    res.json(await scanPlans(settings));
  } catch (error) {
    next(error);
  }
});

app.post("/api/source-folder", sourceUpload.array("files", 50), async (req, res, next) => {
  const stagingDir = `${sourceFilesDir}.upload-${Date.now()}`;
  try {
    if (!req.files?.length) {
      res.status(400).json({ error: "В выбранной папке нет PDF, XLSX или DOCX" });
      return;
    }

    logInfo("upload", "Папка получена", {
      folder: cleanFolderLabel(req.body.folderName),
      files: req.files.length,
      bytes: req.files.reduce((total, file) => total + file.size, 0)
    });
    await fs.mkdir(stagingDir, { recursive: true });
    const usedNames = new Set();
    for (const file of req.files) {
      const fileName = uniqueFileName(decodeUploadName(file.originalname), usedNames);
      await fs.writeFile(path.join(stagingDir, fileName), file.buffer);
    }

    await fs.rm(sourceFilesDir, { recursive: true, force: true });
    await fs.rename(stagingDir, sourceFilesDir);
    logInfo("upload", "Файлы сохранены", { directory: sourceFilesDir, files: req.files.length });
    const settings = await saveSettings({
      ...await getSettings(),
      inputDir: sourceFilesDir,
      inputLabel: cleanFolderLabel(req.body.folderName),
      recursive: false
    });
    restartScheduler(settings, dailyRun);
    const cache = await scanPlans(settings);
    logInfo("upload", "Папка обработана", {
      files: cache.files.length,
      tasks: cache.tasks.length,
      errors: cache.errors.length
    });
    res.json({ settings, cache });
  } catch (error) {
    await fs.rm(stagingDir, { recursive: true, force: true }).catch(() => {});
    next(error);
  }
});

app.get("/api/tasks", async (_req, res, next) => {
  try {
    const cache = await getCache();
    res.json(cache);
  } catch (error) {
    next(error);
  }
});

app.get("/api/source-document", async (req, res, next) => {
  try {
    const filePath = await resolveSourceDocument(req.query.path);
    const fileName = path.basename(filePath);
    res.setHeader("Content-Disposition", `inline; filename*=UTF-8''${encodeURIComponent(fileName)}`);
    res.sendFile(filePath);
  } catch (error) {
    if (error.code === "SOURCE_DOCUMENT_NOT_FOUND") {
      res.status(404).json({ error: "Исходный документ не найден" });
      return;
    }
    next(error);
  }
});

app.get("/api/source-document/preview", async (req, res, next) => {
  try {
    const filePath = await resolveSourceDocument(req.query.path);
    const extension = path.extname(filePath).toLowerCase();
    if (extension === ".pdf") {
      res.type("application/pdf").sendFile(filePath);
      return;
    }

    const title = path.basename(filePath);
    const html = extension === ".docx"
      ? renderDocxPreview(filePath, title)
      : renderUnsupportedPreview(title, extension.slice(1) || "файла");
    res.type("html").send(html);
  } catch (error) {
    if (error.code === "SOURCE_DOCUMENT_NOT_FOUND") {
      res.status(404).type("text").send("Исходный документ не найден");
      return;
    }
    next(error);
  }
});

app.get("/api/errors", async (_req, res, next) => {
  try {
    const cache = await getCache();
    res.json(cache.errors || []);
  } catch (error) {
    next(error);
  }
});

app.get("/api/export.xlsx", async (req, res, next) => {
  try {
    const from = String(req.query.from || "");
    const to = String(req.query.to || "");
    if ((from && !isIsoDate(from)) || (to && !isIsoDate(to))) {
      res.status(400).json({ error: "Диапазон должен быть в формате YYYY-MM-DD" });
      return;
    }
    if (from && to && from > to) {
      res.status(400).json({ error: "Дата начала позже даты окончания" });
      return;
    }

    const result = createDeadlineExport(await getCache(), { from, to });
    logInfo("export", "Excel сформирован", { from: from || null, to: to || null, rows: result.count });
    const suffix = from || to ? `${from || "start"}_${to || "end"}` : "all";
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition", `attachment; filename="deadlines-${suffix}.xlsx"`);
    res.setHeader("X-Export-Count", String(result.count));
    res.send(result.buffer);
  } catch (error) {
    next(error);
  }
});

app.get("/api/summary", async (req, res, next) => {
  try {
    const settings = await getSettings();
    const cache = await getCache();
    res.json(buildSummary(cache, settings, req.query.date || todayIso()));
  } catch (error) {
    next(error);
  }
});

app.post("/api/summary/send", async (req, res, next) => {
  try {
    const settings = await getSettings();
    const cache = await getCache();
    const selectedIds = Array.isArray(req.body.eventIds) ? new Set(req.body.eventIds) : null;
    const summary = selectedIds
      ? buildSummaryFromEvents(
          cache.events.filter((event) => selectedIds.has(event.eventId) && event.status !== "sent"),
          settings,
          req.body.date || todayIso(),
          0
        )
      : buildSummary(cache, settings, req.body.date || todayIso());
    if (!summary.totalEvents && !settings.sendEmptySummary) {
      res.json({ sent: false, summary, message: "Нет задач для отправки" });
      return;
    }
    const info = await sendSummaryEmail(settings, summary);
    const events = summary.groups.flatMap((group) => group.events);
    await addSentEvents(events, {
      emailTo: splitEmails(settings.hrRecipients),
      messageId: info.messageId
    });
    res.json({ sent: true, summary, messageId: info.messageId });
  } catch (error) {
    next(error);
  }
});

app.post("/api/summary/preview", async (req, res, next) => {
  try {
    const currentSettings = await getSettings();
    const settings = {
      ...currentSettings,
      mailBodyTemplate: req.body.mailBodyTemplate ?? currentSettings.mailBodyTemplate
    };
    const cache = await getCache();
    const selectedIds = Array.isArray(req.body.eventIds) ? new Set(req.body.eventIds) : null;
    const summary = selectedIds
      ? buildSummaryFromEvents(
          cache.events.filter((event) => selectedIds.has(event.eventId) && event.status !== "sent"),
          settings,
          req.body.date || todayIso(),
          0
        )
      : buildSummary(cache, settings, req.body.date || todayIso());
    res.json(summary);
  } catch (error) {
    next(error);
  }
});

app.post("/api/mail/test", async (_req, res, next) => {
  try {
    const info = await sendTestEmail(await getSettings());
    res.json({ sent: true, messageId: info.messageId });
  } catch (error) {
    next(error);
  }
});

app.post("/api/events/:eventId/mark-sent", async (req, res, next) => {
  try {
    const cache = await getCache();
    const event = cache.events.find((item) => item.eventId === req.params.eventId);
    if (!event) {
      res.status(404).json({ error: "Событие не найдено" });
      return;
    }
    await addSentEvents([event], { manual: true, emailTo: [] });
    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

app.get("/api/update/status", async (_req, res, next) => {
  try {
    res.json(await getUpdateStatus({ rootDir: path.join(__dirname, "..") }));
  } catch (error) {
    next(error);
  }
});

app.post("/api/update", async (req, res, next) => {
  try {
    if (!isLocalRequest(req)) {
      res.status(403).json({ error: "Обновление разрешено только из локальной программы" });
      return;
    }
    const rootDir = path.join(__dirname, "..");
    const status = await getUpdateStatus({ rootDir });
    if (!status.updateAvailable) {
      res.json({ started: false, ...status });
      return;
    }
    await launchWindowsUpdate({
      rootDir,
      manifestUrl: status.manifestUrl,
      serverProcessId: process.pid
    });
    res.json({ started: true, ...status });
    setTimeout(() => {
      server.close(() => process.exit(0));
      setTimeout(() => process.exit(0), 5_000).unref();
    }, 300).unref();
  } catch (error) {
    next(error);
  }
});

app.use((error, _req, res, _next) => {
  logError("server", "Ошибка запроса", error);
  const status = error instanceof multer.MulterError ? 400 : 500;
  res.status(status).json({ error: error.message || "Internal error" });
});

function decodeUploadName(value) {
  const original = String(value || "file");
  const decoded = Buffer.from(original, "latin1").toString("utf8");
  return decoded.includes("\uFFFD") ? original : decoded;
}

function uniqueFileName(value, usedNames) {
  const safeName = path.basename(value).replace(/[\u0000-\u001f]/g, "").trim() || "file";
  const extension = path.extname(safeName);
  const stem = path.basename(safeName, extension);
  let candidate = safeName;
  let suffix = 2;
  while (usedNames.has(candidate.toLocaleLowerCase("ru"))) {
    candidate = `${stem} (${suffix})${extension}`;
    suffix += 1;
  }
  usedNames.add(candidate.toLocaleLowerCase("ru"));
  return candidate;
}

function cleanFolderLabel(value) {
  return String(value || "Выбранная папка").replace(/[\u0000-\u001f]/g, "").trim().slice(0, 120)
    || "Выбранная папка";
}

function isIsoDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  const date = new Date(year, month - 1, day);
  return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day;
}

function isLocalRequest(req) {
  const origin = req.get("origin");
  if (!origin) return true;
  try {
    const url = new URL(origin);
    return ["localhost", "127.0.0.1"].includes(url.hostname) && Number(url.port || 80) === port;
  } catch {
    return false;
  }
}

async function resolveSourceDocument(requestedPath) {
  const value = String(requestedPath || "");
  const cache = await getCache();
  const allowedPaths = new Set([
    ...(cache.files || []).map((file) => file.path),
    ...(cache.tasks || []).map((task) => task.sourcePath)
  ].filter(Boolean).map((filePath) => path.resolve(filePath)));
  const candidate = path.resolve(value || ".");
  if (!value || !allowedPaths.has(candidate) || !allowedSourceExtensions.has(path.extname(candidate).toLowerCase())) {
    throw sourceDocumentNotFound();
  }

  try {
    const [realCandidate, stat] = await Promise.all([fs.realpath(candidate), fs.stat(candidate)]);
    if (!stat.isFile()) throw sourceDocumentNotFound();
    return realCandidate;
  } catch (error) {
    if (error.code === "SOURCE_DOCUMENT_NOT_FOUND") throw error;
    throw sourceDocumentNotFound();
  }
}

function sourceDocumentNotFound() {
  const error = new Error("Исходный документ не найден");
  error.code = "SOURCE_DOCUMENT_NOT_FOUND";
  return error;
}

const settings = await getSettings();
restartScheduler(settings, dailyRun);

const server = app.listen(port, () => {
  logInfo("server", "Сервис запущен", { url: `http://localhost:${port}` });
});
