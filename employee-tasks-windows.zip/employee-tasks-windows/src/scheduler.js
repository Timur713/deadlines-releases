import cron from "node-cron";
import { todayIso } from "./utils.js";

let task = null;

export function restartScheduler(settings, dailyRun) {
  if (task) {
    task.stop();
    task = null;
  }

  const match = /^(\d{2}):(\d{2})$/.exec(settings.sendTime || "");
  if (!match) return null;

  const minute = Number(match[2]);
  const hour = Number(match[1]);
  if (hour > 23 || minute > 59) return null;

  task = cron.schedule(`${minute} ${hour} * * *`, async () => {
    try {
      await dailyRun(todayIso());
    } catch (error) {
      console.error("[scheduler] daily run failed", error);
    }
  });
  return task;
}
