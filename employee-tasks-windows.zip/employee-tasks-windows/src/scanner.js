import fs from "node:fs/promises";
import path from "node:path";
import { elapsedMs, logError, logInfo } from "./logger.js";
import { parseDeadlineEvents } from "./parsers/dates.js";
import { parsePlanFileCached } from "./parser-cache.js";
import { getSentEvents, saveCache } from "./store.js";
import { renderTemplate } from "./template.js";
import { compareIso, normalizeText, sha256, todayIso } from "./utils.js";

export async function scanPlans(settings) {
  const startedAt = performance.now();
  logInfo("scan", "Сканирование начато", {
    directory: settings.inputDir,
    recursive: Boolean(settings.recursive)
  });
  const files = await findPlanFiles(settings.inputDir, settings.recursive);
  logInfo("scan", "Файлы найдены", {
    count: files.length,
    formats: countFormats(files)
  });
  const parsedFiles = [];
  const tasks = [];
  const events = [];
  const errors = [];
  const seenTasks = new Set();
  const seenEvents = new Set();

  const parsedResults = await mapWithConcurrency(files, 6, async (filePath) => {
    try {
      return { filePath, parsed: await parsePlanFileCached(filePath) };
    } catch (error) {
      return { filePath, error };
    }
  });

  for (const { filePath, parsed, error } of parsedResults) {
    if (error) {
      logError("scan", "Файл не обработан", error, { file: path.basename(filePath) });
      errors.push({
        sourcePath: filePath,
        message: error.message || "Ошибка разбора файла"
      });
      continue;
    }

    parsedFiles.push(parsed.file);
    errors.push(...parsed.errors);

    for (const task of parsed.tasks) {
      const taskKey = sha256([
        task.employeeName,
        task.taskNo,
        task.resultNo,
        task.taskText,
        task.deadlineRaw
      ].map(normalizeText).join("|"));
      if (seenTasks.has(taskKey)) continue;
      seenTasks.add(taskKey);
      tasks.push(task);

      const parsedDeadlines = parseDeadlineEvents(task);
      errors.push(...parsedDeadlines.errors);
      for (const event of parsedDeadlines.events) {
        const eventId = sha256([
          task.employeeName,
          task.taskNo,
          task.resultNo,
          event.dueDate,
          task.taskText
        ].join("|"));
        if (seenEvents.has(eventId)) continue;
        seenEvents.add(eventId);
        events.push({
          eventId,
          ...task,
          ...event,
          status: "pending"
        });
      }
    }
  }

  const sent = new Set((await getSentEvents()).map((item) => item.eventId));
  const annotatedEvents = events.map((event) => ({
    ...event,
    status: sent.has(event.eventId) ? "sent" : event.status
  }));

  const cache = {
    scannedAt: new Date().toISOString(),
    inputDir: settings.inputDir,
    files: parsedFiles,
    tasks,
    events: annotatedEvents.sort((a, b) => compareIso(a.dueDate, b.dueDate)),
    errors
  };
  await saveCache(cache);
  logInfo("scan", "Сканирование завершено", {
    files: parsedFiles.length,
    tasks: tasks.length,
    events: annotatedEvents.length,
    errors: errors.length,
    durationMs: elapsedMs(startedAt)
  });
  return cache;
}

export function buildSummary(cache, settings, date = todayIso()) {
  const lookahead = Number(settings.lookaheadDays || 0);
  const target = new Date(`${date}T00:00:00`);
  const end = new Date(target);
  end.setDate(end.getDate() + lookahead);
  const endIso = todayIso(end);

  const candidates = cache.events.filter((event) => {
    if (event.status === "sent") return false;
    if (!event.dueDate) return false;
    const due = event.dueDate;
    const inWindow = due >= date && due <= endIso;
    const overdue = settings.includeOverdueUnsent && due < date;
    return inWindow || overdue;
  });

  return buildSummaryFromEvents(candidates, settings, date, lookahead);
}

export function buildSummaryFromEvents(events, settings = {}, date = todayIso(), lookaheadDays = 0) {
  const grouped = new Map();
  for (const event of events) {
    if (!grouped.has(event.employeeName)) grouped.set(event.employeeName, []);
    grouped.get(event.employeeName).push(event);
  }
  const groups = [...grouped.entries()].map(([employeeName, events]) => ({
    employeeName,
    employeePosition: events[0]?.employeePosition || "",
    events: events
      .sort((a, b) => compareIso(a.dueDate, b.dueDate))
      .map((event) => ({
        ...event,
        sourceFile: path.basename(event.sourcePath || "")
      }))
  }));
  const text = renderSummaryText(groups, date, events.length, settings.mailBodyTemplate);

  return {
    date,
    lookaheadDays,
    totalEvents: events.length,
    groups,
    html: renderSummaryHtml(text),
    text
  };
}

async function findPlanFiles(inputDir, recursive) {
  const out = [];
  const root = path.resolve(inputDir || ".");
  const entries = await fs.readdir(root, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(root, entry.name);
    if (entry.isDirectory() && recursive) {
      out.push(...await findPlanFiles(fullPath, true));
      continue;
    }
    if (!entry.isFile()) continue;
    if (entry.name.startsWith("~$")) continue;
    if (/\.(docx|xlsx|pdf)$/i.test(entry.name)) out.push(fullPath);
  }

  return out;
}

async function mapWithConcurrency(items, limit, worker) {
  const results = new Array(items.length);
  let nextIndex = 0;

  async function run() {
    while (nextIndex < items.length) {
      const index = nextIndex;
      nextIndex += 1;
      results[index] = await worker(items[index], index);
    }
  }

  const workerCount = Math.min(limit, items.length);
  await Promise.all(Array.from({ length: workerCount }, () => run()));
  return results;
}

function countFormats(files) {
  return files.reduce((counts, filePath) => {
    const format = path.extname(filePath).slice(1).toLowerCase() || "unknown";
    counts[format] = (counts[format] || 0) + 1;
    return counts;
  }, {});
}

function renderSummaryHtml(text) {
  return `<div>${escapeHtml(text).replace(/\n/g, "<br>")}</div>`;
}

function renderSummaryText(groups, date, totalEvents, template) {
  if (!totalEvents) return `На ${date} задач для контроля нет.`;
  return renderTemplate(template, {
    date,
    totalEvents,
    groups
  });
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
