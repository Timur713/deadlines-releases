import path from "node:path";
import { createXlsxBuffer } from "./xlsx-writer.js";

const headers = [
  "Дата",
  "Сотрудник",
  "Должность",
  "№ задачи",
  "Задача",
  "№ результата",
  "Ожидаемый результат",
  "Срок в документе",
  "Статус",
  "Источник",
  "Формат"
];

export function createDeadlineExport(cache, { from = "", to = "" } = {}) {
  const events = (cache.events || [])
    .filter((event) => !from || event.dueDate >= from)
    .filter((event) => !to || event.dueDate <= to)
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate) || a.employeeName.localeCompare(b.employeeName, "ru"));
  const rows = [headers, ...events.map((event) => [
    event.dueDate,
    event.employeeName,
    event.employeePosition,
    event.taskNo,
    event.taskText,
    event.resultNo,
    event.expectedResult,
    event.deadlineRaw,
    event.status === "sent" ? "Отправлено" : "Ожидает",
    path.basename(event.sourcePath || ""),
    path.extname(event.sourcePath || "").slice(1).toUpperCase()
  ])];

  return {
    buffer: createXlsxBuffer({
      sheetName: "Дедлайны",
      rows,
      columnWidths: [14, 30, 24, 12, 48, 16, 54, 30, 14, 34, 10]
    }),
    count: events.length
  };
}
