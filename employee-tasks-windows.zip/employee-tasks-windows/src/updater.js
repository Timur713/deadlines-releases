import fs from "node:fs/promises";
import path from "node:path";
import { spawn } from "node:child_process";

export function compareVersions(left, right) {
  const a = versionParts(left);
  const b = versionParts(right);
  for (let index = 0; index < Math.max(a.length, b.length); index += 1) {
    const difference = (a[index] || 0) - (b[index] || 0);
    if (difference) return Math.sign(difference);
  }
  return 0;
}

export async function getUpdateStatus({ rootDir, fetchImpl = fetch } = {}) {
  const packageJson = await readJson(path.join(rootDir, "package.json"));
  const config = await readJson(path.join(rootDir, "update-config.json"));
  const manifestUrl = process.env.UPDATE_MANIFEST_URL || config.manifestUrl;
  validateRemoteUrl(manifestUrl, "Адрес проверки обновлений");

  const response = await fetchImpl(manifestUrl, {
    headers: {
      "User-Agent": "employee-deadlines-updater",
      "Cache-Control": "no-cache"
    },
    signal: AbortSignal.timeout(12_000)
  });
  if (!response.ok) {
    throw new Error(`Сервер обновлений ответил с кодом ${response.status}`);
  }

  const manifest = await response.json();
  validateManifest(manifest);
  return {
    currentVersion: packageJson.version,
    latestVersion: manifest.version,
    updateAvailable: compareVersions(manifest.version, packageJson.version) > 0,
    manifestUrl
  };
}

export async function launchWindowsUpdate({ rootDir, manifestUrl, serverProcessId = process.pid } = {}) {
  if (process.platform !== "win32" && process.env.ALLOW_WINDOWS_UPDATE !== "1") {
    throw new Error("Автоматическое обновление доступно в собранной Windows-версии");
  }
  validateRemoteUrl(manifestUrl, "Адрес обновления");

  const runtimeDir = path.join(rootDir, ".runtime");
  const sourceScript = path.join(rootDir, "scripts", "windows-updater.ps1");
  const runningScript = path.join(runtimeDir, "windows-updater-running.ps1");
  await fs.mkdir(runtimeDir, { recursive: true });
  await fs.copyFile(sourceScript, runningScript);
  await Promise.all([
    fs.writeFile(path.join(runtimeDir, "update-in-progress.flag"), new Date().toISOString()),
    fs.rm(path.join(runtimeDir, "update-ready.flag"), { force: true }),
    fs.rm(path.join(runtimeDir, "update-error.txt"), { force: true })
  ]);

  try {
    const child = spawn("powershell.exe", [
      "-NoProfile",
      "-ExecutionPolicy", "Bypass",
      "-File", runningScript,
      "-AppRoot", rootDir,
      "-ServerProcessId", String(serverProcessId),
      "-ManifestUrl", manifestUrl
    ], {
      detached: true,
      stdio: "ignore",
      windowsHide: true
    });
    await new Promise((resolve, reject) => {
      child.once("spawn", resolve);
      child.once("error", reject);
    });
    child.unref();
  } catch (error) {
    await fs.rm(path.join(runtimeDir, "update-in-progress.flag"), { force: true });
    throw error;
  }
}

export function validateManifest(manifest) {
  if (!/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/.test(String(manifest?.version || ""))) {
    throw new Error("В манифесте обновления указана некорректная версия");
  }
  validateRemoteUrl(manifest.downloadUrl, "Адрес архива обновления");
  if (!/^[a-fA-F0-9]{64}$/.test(String(manifest.sha256 || ""))) {
    throw new Error("В манифесте обновления отсутствует корректная SHA-256 сумма");
  }
}

function validateRemoteUrl(value, label) {
  let url;
  try {
    url = new URL(value);
  } catch {
    throw new Error(`${label} некорректен`);
  }
  if (url.protocol !== "https:" && !(url.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url.hostname))) {
    throw new Error(`${label} должен использовать HTTPS`);
  }
}

function versionParts(version) {
  const match = /^(\d+)\.(\d+)\.(\d+)/.exec(String(version || ""));
  if (!match) return [0, 0, 0];
  return match.slice(1).map(Number);
}

async function readJson(filePath) {
  return JSON.parse(await fs.readFile(filePath, "utf8"));
}
