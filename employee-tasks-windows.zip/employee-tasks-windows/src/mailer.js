import nodemailer from "nodemailer";
import { elapsedMs, logInfo } from "./logger.js";
import { splitEmails } from "./utils.js";

export function createTransport(settings) {
  const port = Number(settings.smtpPort || 587);
  const security = port === 465 ? "ssl" : settings.smtpSecurity || "starttls";
  const auth = settings.smtpUser
    ? { user: settings.smtpUser, pass: settings.smtpPass || "" }
    : undefined;

  return nodemailer.createTransport({
    host: settings.smtpHost,
    port,
    secure: security === "ssl",
    requireTLS: security === "starttls",
    ignoreTLS: security === "none",
    auth
  });
}

export async function sendSummaryEmail(settings, summary) {
  const recipients = splitEmails(settings.hrRecipients);
  if (!settings.smtpHost) throw new Error("SMTP host не заполнен");
  if (!settings.mailFrom) throw new Error("Адрес отправителя не заполнен");
  if (!recipients.length) throw new Error("Получатели HR не заполнены");

  const transporter = createTransport(settings);
  const startedAt = performance.now();
  logInfo("mail", "Отправка письма начата", {
    recipients: recipients.length,
    events: summary.totalEvents,
    date: summary.date
  });
  const result = await transporter.sendMail({
    from: settings.mailFrom,
    to: recipients,
    subject: `${settings.mailSubjectPrefix || "Задачи ИС на контроль"}: ${summary.date}`,
    text: summary.text,
    html: summary.html
  });
  logInfo("mail", "Письмо отправлено", {
    messageId: result.messageId,
    durationMs: elapsedMs(startedAt)
  });
  return result;
}

export async function sendTestEmail(settings) {
  const recipients = splitEmails(settings.hrRecipients);
  if (!recipients.length) throw new Error("Получатели HR не заполнены");
  const transporter = createTransport(settings);
  return transporter.sendMail({
    from: settings.mailFrom,
    to: recipients,
    subject: "Тест SMTP: Контроль ИС",
    text: "Тестовое письмо от локального сервиса контроля дедлайнов ИС.",
    html: "<p>Тестовое письмо от локального сервиса контроля дедлайнов ИС.</p>"
  });
}
