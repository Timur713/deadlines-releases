import fs from "node:fs/promises";
import path from "node:path";
import { parseDocx } from "./parsers/docx.js";
import { parsePdf } from "./parsers/pdf.js";
import { parseXlsx } from "./parsers/xlsx.js";
import { elapsedMs, logInfo } from "./logger.js";
import { readJson, sha256, writeJson } from "./utils.js";

const CACHE_SCHEMA = "plan-parser-v5";
const defaultCacheDir = path.resolve(process.cwd(), "data", "parser-cache");
const inFlight = new Map();

export async function parsePlanFileCached(filePath, options = {}) {
  const startedAt = performance.now();
  const fileName = path.basename(filePath);
  const cacheDir = options.cacheDir || defaultCacheDir;
  const extension = path.extname(filePath).toLowerCase();
  const [content, stat] = await Promise.all([fs.readFile(filePath), fs.stat(filePath)]);
  const contentHash = sha256(content);
  const cacheKey = `${CACHE_SCHEMA}-${extension.slice(1)}-${contentHash}`;
  const cachePath = path.join(cacheDir, `${cacheKey}.json`);
  const cached = await readJson(cachePath, null);

  if (cached?.schema === CACHE_SCHEMA && cached.result) {
    logInfo("cache", "Файл взят из кэша", {
      file: fileName,
      format: extension.slice(1),
      durationMs: elapsedMs(startedAt)
    });
    return rebaseResult(cached.result, filePath, stat, contentHash, true);
  }

  let parsePromise = inFlight.get(cachePath);
  if (!parsePromise) {
    logInfo("parser", "Начат разбор файла", { file: fileName, format: extension.slice(1) });
    parsePromise = parseAndCache(filePath, extension, cachePath);
    inFlight.set(cachePath, parsePromise);
  } else {
    logInfo("cache", "Ожидание уже запущенного разбора", { file: fileName });
  }

  try {
    const result = await parsePromise;
    logInfo("parser", "Разбор файла завершён", {
      file: fileName,
      format: extension.slice(1),
      tasks: result.tasks?.length || 0,
      errors: result.errors?.length || 0,
      durationMs: elapsedMs(startedAt)
    });
    return rebaseResult(result, filePath, stat, contentHash, false);
  } finally {
    if (inFlight.get(cachePath) === parsePromise) inFlight.delete(cachePath);
  }
}

async function parseAndCache(filePath, extension, cachePath) {
  const parser = extension === ".docx"
    ? parseDocx
    : extension === ".pdf"
      ? parsePdf
      : parseXlsx;
  const result = await parser(filePath);
  await writeJson(cachePath, { schema: CACHE_SCHEMA, result });
  logInfo("cache", "Результат разбора сохранён", { file: path.basename(filePath) });
  return result;
}

function rebaseResult(result, filePath, stat, contentHash, cacheHit) {
  return {
    file: {
      ...result.file,
      path: filePath,
      mtimeMs: stat.mtimeMs,
      size: stat.size,
      hash: contentHash,
      cacheHit
    },
    tasks: (result.tasks || []).map((task) => ({
      ...task,
      sourcePath: filePath,
      taskId: sha256(`${filePath}|${task.employeeName}|${task.taskNo}|${task.taskText}`)
    })),
    errors: (result.errors || []).map((error) => ({
      ...error,
      sourcePath: error.sourcePath ? filePath : error.sourcePath
    }))
  };
}
