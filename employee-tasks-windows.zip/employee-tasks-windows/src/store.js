import path from "node:path";
import { DEFAULT_MAIL_BODY_TEMPLATE } from "./template.js";
import { ensureDir, readJson, writeJson } from "./utils.js";

const dataDir = path.resolve(process.cwd(), "data");
const settingsPath = path.join(dataDir, "settings.json");
const cachePath = path.join(dataDir, "cache.json");
const sentPath = path.join(dataDir, "sent.json");

export const defaultSettings = {
  inputDir: path.resolve(process.cwd(), "plans"),
  recursive: false,
  lookaheadDays: 0,
  includeOverdueUnsent: true,
  sendEmptySummary: false,
  sendTime: "09:00",
  smtpHost: "",
  smtpPort: 587,
  smtpSecurity: "starttls",
  smtpUser: "",
  smtpPass: "",
  mailFrom: "",
  hrRecipients: "",
  mailSubjectPrefix: "Задачи ИС на контроль",
  mailBodyTemplate: DEFAULT_MAIL_BODY_TEMPLATE
};

export async function getSettings() {
  await ensureDir(dataDir);
  return { ...defaultSettings, ...(await readJson(settingsPath, {})) };
}

export async function saveSettings(settings) {
  const current = await getSettings();
  const smtpPort = Number(settings.smtpPort || current.smtpPort || 587);
  const requestedSecurity = settings.smtpSecurity || current.smtpSecurity || "starttls";
  const next = {
    ...current,
    ...settings,
    smtpPort,
    smtpSecurity: smtpPort === 465 ? "ssl" : requestedSecurity,
    lookaheadDays: Number(settings.lookaheadDays ?? current.lookaheadDays ?? 0),
    recursive: Boolean(settings.recursive),
    includeOverdueUnsent: Boolean(settings.includeOverdueUnsent),
    sendEmptySummary: Boolean(settings.sendEmptySummary)
  };
  await writeJson(settingsPath, next);
  return next;
}

export async function getCache() {
  return readJson(cachePath, {
    scannedAt: null,
    files: [],
    tasks: [],
    events: [],
    errors: []
  });
}

export async function saveCache(cache) {
  await writeJson(cachePath, cache);
  return cache;
}

export async function getSentEvents() {
  return readJson(sentPath, []);
}

export async function addSentEvents(events, meta) {
  const current = await getSentEvents();
  const existing = new Set(current.map((item) => item.eventId));
  const now = new Date().toISOString();
  const additions = events
    .filter((event) => !existing.has(event.eventId))
    .map((event) => ({
      eventId: event.eventId,
      employeeName: event.employeeName,
      taskNo: event.taskNo,
      resultNo: event.resultNo,
      dueDate: event.dueDate,
      sourcePath: event.sourcePath,
      sentAt: now,
      emailTo: meta.emailTo,
      messageId: meta.messageId || null,
      manual: Boolean(meta.manual)
    }));
  const next = [...current, ...additions];
  await writeJson(sentPath, next);
  return additions;
}
