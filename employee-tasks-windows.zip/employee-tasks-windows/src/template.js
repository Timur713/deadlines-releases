export const DEFAULT_MAIL_BODY_TEMPLATE = `Добрый день.

На {{ date }} есть задачи, по которым нужно запросить статус:

{% for group in groups %}
{{ group.employeeName }}
{% for event in group.events %}
- {{ event.dueDate }}, задача {{ event.taskNo }}
  {{ event.taskText }}
  Ожидаемый результат: {{ event.expectedResult }}
  Файл: {{ event.sourceFile }}
{% endfor %}

{% endfor %}`;

export function renderTemplate(template, data) {
  return renderBlock(String(template || DEFAULT_MAIL_BODY_TEMPLATE), data).trim();
}

function renderBlock(source, scope) {
  let output = "";
  let cursor = 0;
  const forRe = /{%\s*for\s+([A-Za-z_$][\w$]*)\s+in\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*%}/g;

  for (;;) {
    const match = forRe.exec(source);
    if (!match) break;

    output += renderVariables(source.slice(cursor, match.index), scope);

    const close = findMatchingEndFor(source, forRe.lastIndex);
    if (!close) {
      output += renderVariables(source.slice(match.index), scope);
      cursor = source.length;
      break;
    }

    const itemName = match[1];
    const collection = resolvePath(scope, match[2]);
    const block = source.slice(forRe.lastIndex, close.start);

    if (Array.isArray(collection)) {
      collection.forEach((item, index) => {
        output += renderBlock(block, {
          ...scope,
          [itemName]: item,
          loop: {
            index: index + 1,
            index0: index,
            first: index === 0,
            last: index === collection.length - 1
          }
        });
      });
    }

    cursor = close.end;
    forRe.lastIndex = close.end;
  }

  output += renderVariables(source.slice(cursor), scope);
  return output;
}

function findMatchingEndFor(source, offset) {
  const tagRe = /{%\s*(for\s+[A-Za-z_$][\w$]*\s+in\s+[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*|endfor)\s*%}/g;
  tagRe.lastIndex = offset;
  let depth = 1;

  for (;;) {
    const match = tagRe.exec(source);
    if (!match) return null;
    if (match[1].startsWith("for ")) depth += 1;
    if (match[1] === "endfor") depth -= 1;
    if (depth === 0) return { start: match.index, end: tagRe.lastIndex };
  }
}

function renderVariables(source, scope) {
  return source.replace(/{{\s*([^}]+?)\s*}}/g, (_match, expression) => {
    const value = evaluateExpression(expression, scope);
    return value == null ? "" : String(value);
  });
}

function evaluateExpression(expression, scope) {
  const [path, ...filters] = String(expression).split("|").map((part) => part.trim());
  let value = resolvePath(scope, path);

  for (const filter of filters) {
    const defaultMatch = /^default\((.*)\)$/.exec(filter);
    if (defaultMatch && (value == null || value === "")) {
      value = parseLiteral(defaultMatch[1]);
    }
  }

  return value;
}

function resolvePath(scope, path) {
  if (!path) return "";
  return String(path).split(".").reduce((current, key) => {
    if (current == null) return "";
    return current[key];
  }, scope);
}

function parseLiteral(value) {
  const trimmed = String(value).trim();
  const quoted = /^['"](.*)['"]$/.exec(trimmed);
  return quoted ? quoted[1] : trimmed;
}
