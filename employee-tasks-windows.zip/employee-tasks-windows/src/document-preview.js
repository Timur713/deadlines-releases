import AdmZip from "adm-zip";

export function renderDocxPreview(filePath, title = "Документ") {
  const zip = new AdmZip(filePath);
  const entry = zip.getEntry("word/document.xml");
  if (!entry) throw new Error("word/document.xml не найден");

  const xml = entry.getData().toString("utf8");
  const body = xml.match(/<w:body\b[^>]*>([\s\S]*?)<\/w:body>/)?.[1] || xml;
  const blocks = [...body.matchAll(/<w:(p|tbl)\b[\s\S]*?<\/w:\1>/g)].map((match) => match[0]);
  const content = blocks.map((block) => block.startsWith("<w:tbl")
    ? renderTable(block)
    : renderParagraph(block)).join("");

  return `<!doctype html>
<html lang="ru">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>${escapeHtml(title)}</title>
    <style>
      * { box-sizing: border-box; }
      body { margin: 0; background: #eef1f5; color: #1f2937; font: 14px/1.45 Arial, sans-serif; }
      main { width: min(960px, calc(100% - 32px)); min-height: calc(100vh - 32px); margin: 16px auto; padding: 44px 48px; background: #fff; box-shadow: 0 1px 5px rgba(15, 23, 42, .13); }
      p { min-height: 1em; margin: 0 0 10px; white-space: pre-wrap; }
      table { width: 100%; margin: 14px 0; border-collapse: collapse; table-layout: fixed; }
      td { border: 1px solid #9ca3af; padding: 7px; vertical-align: top; overflow-wrap: anywhere; }
      td p { margin: 0 0 5px; }
      td p:last-child { margin-bottom: 0; }
      @media (max-width: 700px) { main { width: 100%; margin: 0; padding: 22px 16px; } }
    </style>
  </head>
  <body><main>${content || "<p>Документ не содержит доступного для просмотра текста.</p>"}</main></body>
</html>`;
}

export function renderUnsupportedPreview(title, extension) {
  return `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${escapeHtml(title)}</title><style>body{margin:0;background:#eef1f5;color:#1f2937;font:14px Arial,sans-serif}main{max-width:560px;margin:48px auto;padding:28px;background:#fff;border:1px solid #d9dee7;border-radius:8px}h1{font-size:18px}p{line-height:1.5;color:#6b7280}</style></head><body><main><h1>${escapeHtml(title)}</h1><p>Встроенный просмотр ${escapeHtml(extension.toUpperCase())} не поддерживается браузером. Используйте кнопку «Открыть оригинал» над документом.</p></main></body></html>`;
}

function renderTable(xml) {
  const rows = xml.match(/<w:tr\b[\s\S]*?<\/w:tr>/g) || [];
  return `<table><tbody>${rows.map((row) => {
    const cells = row.match(/<w:tc\b[\s\S]*?<\/w:tc>/g) || [];
    return `<tr>${cells.map((cell) => {
      const paragraphs = cell.match(/<w:p\b[\s\S]*?<\/w:p>/g) || [];
      return `<td>${paragraphs.map(renderParagraph).join("") || "&nbsp;"}</td>`;
    }).join("")}</tr>`;
  }).join("")}</tbody></table>`;
}

function renderParagraph(xml) {
  const parts = [...xml.matchAll(/<w:t\b[^>]*>([\s\S]*?)<\/w:t>|<w:(?:br|tab)\b[^>]*\/?\s*>/g)]
    .map((match) => match[1] == null
      ? match[0].startsWith("<w:tab") ? "\t" : "\n"
      : decodeXml(match[1]));
  const text = parts.join("");
  return `<p>${text ? escapeHtml(text) : "&nbsp;"}</p>`;
}

function decodeXml(value) {
  return String(value)
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, "\"")
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_match, code) => String.fromCodePoint(Number(code)))
    .replace(/&#x([\da-f]+);/gi, (_match, code) => String.fromCodePoint(Number.parseInt(code, 16)))
    .replace(/&amp;/g, "&");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
