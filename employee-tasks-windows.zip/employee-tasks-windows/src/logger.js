export function logInfo(scope, message, details = {}) {
  const suffix = Object.keys(details).length ? ` ${JSON.stringify(details)}` : "";
  console.log(`${new Date().toISOString()} [${scope}] ${message}${suffix}`);
}

export function logError(scope, message, error, details = {}) {
  logInfo(scope, message, {
    ...details,
    error: error?.message || String(error || "Неизвестная ошибка")
  });
}

export function elapsedMs(startedAt) {
  return Math.round(performance.now() - startedAt);
}
