const state = {
  settings: null,
  cache: { files: [], tasks: [], events: [], errors: [] },
  selectedDate: todayIso(),
  monthCursor: firstDayOfMonth(new Date()),
  selectedEmployeeName: null,
  selectedDocumentPath: null,
  employeeQuery: ""
};

const $ = (selector) => document.querySelector(selector);
let previewRequestId = 0;

init();

async function init() {
  bindActions();
  await loadSettings();
  await loadCache();
  render();
}

function bindActions() {
  $("#sourceForm").addEventListener("submit", (event) => event.preventDefault());
  $("#exportForm").addEventListener("submit", (event) => event.preventDefault());
  $("#mailForm").addEventListener("submit", (event) => event.preventDefault());

  $("#chooseFolderBtn").addEventListener("click", () => $("#folderInput").click());
  $("#folderInput").addEventListener("change", uploadSelectedFolder);

  $("#scanBtn").addEventListener("click", withBusy("#scanBtn", async () => {
    await saveSettings({ quiet: true });
    state.cache = await api("/api/scan", { method: "POST" });
    render();
    toast("Данные обновлены");
  }));

  $("#softwareUpdateBtn").addEventListener("click", withBusy("#softwareUpdateBtn", async () => {
    const status = await api("/api/update/status");
    if (!status.updateAvailable) {
      toast(`Установлена актуальная версия ${status.currentVersion}`);
      return;
    }
    const accepted = window.confirm(
      `Доступна версия ${status.latestVersion} (сейчас ${status.currentVersion}).\n\n` +
      "Установить обновление? Программа перезапустится, настройки и документы сохранятся."
    );
    if (!accepted) return;

    const result = await api("/api/update", { method: "POST" });
    if (!result.started) {
      toast("Обновление уже не требуется");
      return;
    }
    $("#softwareUpdateBtn").textContent = "Обновляю...";
    toast("Обновление началось. Не закрывайте окно запуска.");
    await waitForUpdatedServer();
  }));

  $("#exportBtn").addEventListener("click", withBusy("#exportBtn", downloadExport));

  $("#prevMonthBtn").addEventListener("click", () => {
    state.monthCursor.setMonth(state.monthCursor.getMonth() - 1);
    state.monthCursor = firstDayOfMonth(state.monthCursor);
    renderCalendar();
  });

  $("#nextMonthBtn").addEventListener("click", () => {
    state.monthCursor.setMonth(state.monthCursor.getMonth() + 1);
    state.monthCursor = firstDayOfMonth(state.monthCursor);
    renderCalendar();
  });

  $("#mailBodyTemplate").addEventListener("input", debounce(renderMailPreview, 250));
  $("#employeeSearch").addEventListener("input", (event) => {
    state.employeeQuery = event.target.value.trim().toLocaleLowerCase("ru");
    renderEmployees();
  });
  $("#documentSelect").addEventListener("change", (event) => {
    state.selectedDocumentPath = event.target.value;
    renderDocument();
  });

  $("#sendBtn").addEventListener("click", withBusy("#sendBtn", async () => {
    await saveSettings({ quiet: true });
    const events = selectedDayEvents().filter((event) => event.status !== "sent");
    if (!events.length) {
      toast("На выбранный день нет неотправленных задач", true);
      return;
    }
    const result = await api("/api/summary/send", {
      method: "POST",
      body: {
        date: state.selectedDate,
        eventIds: events.map((event) => event.eventId)
      }
    });
    await loadCache();
    render();
    toast(result.sent ? "Письмо отправлено" : result.message);
  }));
}

async function waitForUpdatedServer() {
  let wasOffline = false;
  for (let attempt = 0; attempt < 180; attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, 1_000));
    try {
      const response = await fetch("/api/settings", { cache: "no-store" });
      if (wasOffline && response.ok) {
        window.location.reload();
        return;
      }
    } catch {
      wasOffline = true;
    }
  }
  throw new Error("Обновление занимает слишком много времени. Проверьте окно запуска программы.");
}

async function loadSettings() {
  state.settings = await api("/api/settings");
  fillForms(state.settings);
  renderFolderLabel();
}

async function loadCache() {
  state.cache = await api("/api/tasks");
}

async function saveSettings(options = {}) {
  const mailData = Object.fromEntries(new FormData($("#mailForm")).entries());
  state.settings = await api("/api/settings", {
    method: "POST",
    body: {
      ...mailData,
      recursive: false,
      includeOverdueUnsent: true,
      sendEmptySummary: false
    }
  });
  fillForms(state.settings);
  if (!options.quiet) toast("Настройки сохранены");
}

async function uploadSelectedFolder() {
  const input = $("#folderInput");
  const files = [...input.files].filter((file) => /\.(pdf|xlsx|docx)$/i.test(file.name));
  if (!files.length) {
    input.value = "";
    toast("В папке нет PDF, XLSX или DOCX", true);
    return;
  }

  const button = $("#chooseFolderBtn");
  const originalText = button.textContent;
  button.disabled = true;
  $("#scanBtn").disabled = true;
  button.textContent = "Обрабатываю...";
  try {
    const body = new FormData();
    for (const file of files) body.append("files", file, file.name);
    body.append("folderName", selectedFolderName(input.files));
    const response = await fetch("/api/source-folder", { method: "POST", body });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || "Не удалось загрузить папку");
    state.settings = payload.settings;
    state.cache = payload.cache;
    renderFolderLabel();
    render();
    toast(`Загружено файлов: ${state.cache.files.length}`);
  } catch (error) {
    toast(error.message || "Ошибка загрузки", true);
  } finally {
    input.value = "";
    button.textContent = originalText;
    button.disabled = false;
    $("#scanBtn").disabled = false;
  }
}

function selectedFolderName(fileList) {
  const relativePath = fileList[0]?.webkitRelativePath || "";
  return relativePath.split("/")[0] || "Выбранная папка";
}

function renderFolderLabel() {
  const fallback = fileName(state.settings?.inputDir || "");
  $("#folderLabel").textContent = state.settings?.inputLabel || fallback || "Папка не выбрана";
}

function fillForms(settings) {
  for (const form of [$("#sourceForm"), $("#mailForm")]) {
    for (const [key, value] of Object.entries(settings)) {
      if (!form.elements[key]) continue;
      form.elements[key].value = value ?? "";
    }
  }
}

function render() {
  const cache = state.cache;
  $("#statusText").textContent = cache.scannedAt
    ? `Файлов: ${cache.files.length}. Задач: ${cache.tasks.length}. Ошибок: ${cache.errors.length}.`
    : "Выберите папку с планами и запустите сканирование.";

  ensureValidEmployeeSelection();
  renderEmployees();
  renderEmployeeOverview();
  renderCalendar();
  renderDay();
  renderDocument();
}

function renderEmployees() {
  const employees = allEmployees();
  const visibleEmployees = employees.filter((employee) => {
    if (!state.employeeQuery) return true;
    return `${employee.name} ${employee.position}`.toLocaleLowerCase("ru").includes(state.employeeQuery);
  });
  $("#employeesCount").textContent = plural(employees.length, ["сотрудник", "сотрудника", "сотрудников"]);
  $("#employeeList").innerHTML = [
    `<button class="employee-button ${state.selectedEmployeeName ? "" : "active"}" type="button" data-employee="">
      <span class="employee-avatar all-avatar">Все</span>
      <span class="employee-button-copy"><strong>Все сотрудники</strong><small>Общий календарь</small></span>
      <span class="employee-task-count">${state.cache.tasks.length}</span>
    </button>`,
    ...visibleEmployees.map((employee) => `
      <button class="employee-button ${employee.name === state.selectedEmployeeName ? "active" : ""}" type="button" data-employee="${escapeHtml(employee.name)}">
        <span class="employee-avatar">${escapeHtml(initials(employee.name))}</span>
        <span class="employee-button-copy"><strong>${escapeHtml(employee.name)}</strong><small>${escapeHtml(employee.position || "Должность не указана")}</small></span>
        <span class="employee-task-count">${employee.tasks.length}</span>
      </button>
    `),
    ...(state.employeeQuery && !visibleEmployees.length ? [`<div class="employee-not-found">Сотрудники не найдены</div>`] : [])
  ].join("");

  document.querySelectorAll(".employee-button").forEach((button) => {
    button.addEventListener("click", () => {
      state.selectedEmployeeName = button.dataset.employee || null;
      state.selectedDocumentPath = selectedEmployeeDocuments()[0] || null;
      renderEmployees();
      renderEmployeeOverview();
      renderCalendar();
      renderDay();
      renderDocument();
    });
  });
}

function renderEmployeeOverview() {
  const overview = $("#employeeOverview");

  if (!state.selectedEmployeeName) {
    overview.innerHTML = `
      <div class="overview-identity">
        <span class="overview-avatar all-avatar">ИС</span>
        <div><span class="eyebrow">Общий обзор</span><h2>Все сотрудники</h2><p>Сводный календарь испытательных сроков</p></div>
      </div>
      <div class="overview-metrics">
        ${overviewMetric(allEmployees().length, "сотрудников")}
        ${overviewMetric(state.cache.tasks.length, "задач")}
      </div>`;
    return;
  }

  const employee = allEmployees().find((item) => item.name === state.selectedEmployeeName);
  const firstTask = employee?.tasks[0] || {};
  const period = formatPeriod(firstTask.probationStart, firstTask.probationEnd);
  overview.innerHTML = `
    <div class="overview-identity">
      <span class="overview-avatar">${escapeHtml(initials(state.selectedEmployeeName))}</span>
      <div><span class="eyebrow">Карточка сотрудника</span><h2>${escapeHtml(state.selectedEmployeeName)}</h2><p>${escapeHtml(employee?.position || "Должность не указана")}</p></div>
    </div>
    <div class="overview-metrics">
      ${overviewMetric(employee?.tasks.length || 0, "задач")}
      ${overviewMetric(period, "период ИС")}
    </div>`;
}

function renderCalendar() {
  const currentIso = todayIso();
  $("#monthTitle").textContent = state.monthCursor.toLocaleDateString("ru-RU", {
    month: "long",
    year: "numeric"
  });
  $("#todayText").textContent = `Сегодня: ${formatDate(currentIso)}`;

  const counts = countEventsByDate(filteredEvents());
  const cells = calendarCells(state.monthCursor);
  $("#calendarGrid").innerHTML = cells.map((date) => {
    const iso = toIso(date);
    const count = counts.get(iso) || 0;
    const outside = date.getMonth() !== state.monthCursor.getMonth();
    const selected = iso === state.selectedDate;
    const today = iso === currentIso;
    return `
      <button class="day ${outside ? "outside" : ""} ${selected ? "selected" : ""} ${today ? "today" : ""}" data-date="${iso}" type="button">
        <span class="day-number">${date.getDate()}</span>
        ${today ? `<span class="today-marker">сегодня</span>` : ""}
        ${count ? `<span class="day-count">${count}</span>` : ""}
      </button>
    `;
  }).join("");

  document.querySelectorAll(".day").forEach((button) => {
    button.addEventListener("click", () => {
      state.selectedDate = button.dataset.date;
      renderCalendar();
      renderDay();
    });
  });
}

function renderDay() {
  $("#mailDateLabel").textContent = `За ${formatDate(state.selectedDate)}`;
  if (state.selectedEmployeeName) {
    renderEmployeeTasks();
    renderMailPreview();
    return;
  }

  const events = selectedDayEvents();
  $("#dayTitle").textContent = formatDate(state.selectedDate);
  $("#daySubtitle").textContent = "Сотрудники и задачи";
  $("#dayCount").textContent = plural(events.length, ["задача", "задачи", "задач"]);
  $("#sendBtn").disabled = !events.some((event) => event.status !== "sent");

  $("#taskList").innerHTML = events.length
    ? groupEventsByEmployee(events).map((group) => `
      <section class="employee-group">
        <div class="employee-head">
          <strong>${escapeHtml(group.employeeName)}</strong>
          <span>${plural(group.events.length, ["задача", "задачи", "задач"])}</span>
        </div>
        ${group.events.map((event) => `
          ${taskDisclosure(event, formatShortDate(event.dueDate))}
        `).join("")}
      </section>
    `).join("")
    : `<div class="empty">На этот день задач нет.</div>`;
  renderMailPreview();
}

function renderEmployeeTasks() {
  const tasks = (state.cache.tasks || [])
    .filter((task) => task.employeeName === state.selectedEmployeeName)
    .sort(compareTaskNumbers);
  const employee = allEmployees().find((item) => item.name === state.selectedEmployeeName);
  const dayEvents = selectedDayEvents();

  $("#dayTitle").textContent = state.selectedEmployeeName;
  $("#daySubtitle").textContent = employee?.position || "Все задачи сотрудника";
  $("#dayCount").textContent = plural(tasks.length, ["задача", "задачи", "задач"]);
  $("#sendBtn").disabled = !dayEvents.some((event) => event.status !== "sent");
  $("#taskList").innerHTML = tasks.length
    ? `<section class="employee-group employee-tasks">${tasks.map((task) => `
      ${taskDisclosure(task, taskDeadlineLabel(task))}
    `).join("")}</section>`
    : `<div class="empty">У сотрудника нет задач.</div>`;
}

function renderDocument() {
  const panel = $("#documentPanel");
  const documents = selectedEmployeeDocuments();
  if (!state.selectedEmployeeName || !documents.length) {
    panel.classList.add("empty-document");
    $("#documentActions").hidden = true;
    $("#documentEmpty").hidden = false;
    $("#documentName").textContent = state.selectedEmployeeName
      ? "Для сотрудника исходный файл не найден"
      : "Выберите сотрудника слева";
    $("#documentFrame").hidden = true;
    $("#documentFrame").removeAttribute("src");
    return;
  }

  if (!documents.includes(state.selectedDocumentPath)) state.selectedDocumentPath = documents[0];
  const selectedPath = state.selectedDocumentPath;
  const select = $("#documentSelect");
  select.innerHTML = documents.map((documentPath) => `
    <option value="${escapeHtml(documentPath)}" ${documentPath === selectedPath ? "selected" : ""}>${escapeHtml(fileName(documentPath))}</option>
  `).join("");
  select.hidden = documents.length < 2;

  const params = new URLSearchParams({ path: selectedPath });
  $("#documentName").textContent = fileName(selectedPath);
  $("#openDocumentLink").href = `/api/source-document?${params}`;
  const previewUrl = `/api/source-document/preview?${params}`;
  if ($("#documentFrame").getAttribute("src") !== previewUrl) {
    $("#documentFrame").src = previewUrl;
  }
  panel.classList.remove("empty-document");
  $("#documentActions").hidden = false;
  $("#documentEmpty").hidden = true;
  $("#documentFrame").hidden = false;
}

function groupEventsByEmployee(events) {
  const map = new Map();
  for (const event of events) {
    if (!map.has(event.employeeName)) map.set(event.employeeName, []);
    map.get(event.employeeName).push(event);
  }
  return [...map.entries()]
    .map(([employeeName, employeeEvents]) => ({
      employeeName,
      events: employeeEvents.sort(compareTaskNumbers)
    }))
    .sort((a, b) => a.employeeName.localeCompare(b.employeeName, "ru"));
}

function selectedDayEvents() {
  return filteredEvents().filter((event) => event.dueDate === state.selectedDate);
}

function filteredEvents() {
  const events = state.cache.events || [];
  return state.selectedEmployeeName
    ? events.filter((event) => event.employeeName === state.selectedEmployeeName)
    : events;
}

function allEmployees() {
  const employees = new Map();
  for (const task of state.cache.tasks || []) {
    if (!task.employeeName) continue;
    if (!employees.has(task.employeeName)) {
      employees.set(task.employeeName, { name: task.employeeName, position: task.employeePosition || "", tasks: [] });
    }
    employees.get(task.employeeName).tasks.push(task);
  }
  return [...employees.values()].sort((a, b) => a.name.localeCompare(b.name, "ru"));
}

function selectedEmployeeDocuments() {
  if (!state.selectedEmployeeName) return [];
  return [...new Set((state.cache.tasks || [])
    .filter((task) => task.employeeName === state.selectedEmployeeName && task.sourcePath)
    .map((task) => task.sourcePath))];
}

function ensureValidEmployeeSelection() {
  if (!state.selectedEmployeeName) return;
  if (allEmployees().some((employee) => employee.name === state.selectedEmployeeName)) return;
  state.selectedEmployeeName = null;
  state.selectedDocumentPath = null;
}

function compareTaskNumbers(a, b) {
  return String(a.taskNo || "").localeCompare(String(b.taskNo || ""), "ru", {
    numeric: true,
    sensitivity: "base"
  });
}

function taskDisclosure(task, deadline) {
  return `<details class="task-disclosure">
    <summary>
      <span class="task-summary-title"><strong>Задача ${escapeHtml(task.taskNo || "—")}</strong>${task.resultNo ? `<small>Результат ${escapeHtml(task.resultNo)}</small>` : ""}</span>
      <span class="task-deadline"><span aria-hidden="true">▣</span>${escapeHtml(deadline || "Срок не указан")}</span>
      <span class="task-chevron" aria-hidden="true">⌄</span>
    </summary>
    <div class="task-detail">
      <div><span class="task-detail-label">Описание задачи</span><p>${escapeHtml(task.taskText || "—")}</p></div>
      <div><span class="task-detail-label">Ожидаемый результат</span><p>${escapeHtml(task.expectedResult || "—")}</p></div>
      ${task.sourcePath ? `<small class="task-source">Источник: ${escapeHtml(fileName(task.sourcePath))}</small>` : ""}
    </div>
  </details>`;
}

function taskDeadlineLabel(task) {
  const dates = [...new Set((state.cache.events || [])
    .filter((event) => event.taskId === task.taskId && event.dueDate)
    .map((event) => formatShortDate(event.dueDate)))];
  if (!dates.length) return task.deadlineRaw || "Срок не указан";
  if (dates.length <= 3) return dates.join(" · ");
  return `${dates.slice(0, 3).join(" · ")} · ещё ${dates.length - 3}`;
}

function overviewMetric(value, label, tone = "") {
  return `<div class="overview-metric ${tone}"><strong>${escapeHtml(value)}</strong><span>${escapeHtml(label)}</span></div>`;
}

function initials(name) {
  return String(name || "")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toLocaleUpperCase("ru");
}

function formatPeriod(from, to) {
  if (!from && !to) return "Не указан";
  if (from && to) return `${formatShortDate(from)} — ${formatShortDate(to)}`;
  return formatShortDate(from || to);
}

function formatShortDate(iso) {
  if (!iso) return "—";
  return parseIso(iso).toLocaleDateString("ru-RU", { day: "2-digit", month: "short", year: "numeric" });
}

async function downloadExport() {
  const from = $("#exportFrom").value;
  const to = $("#exportTo").value;
  if (from && to && from > to) throw new Error("Дата начала позже даты окончания");

  const params = new URLSearchParams();
  if (from) params.set("from", from);
  if (to) params.set("to", to);
  const response = await fetch(`/api/export.xlsx?${params}`);
  if (!response.ok) {
    const payload = await response.json().catch(() => ({}));
    throw new Error(payload.error || "Не удалось сформировать Excel");
  }

  const blob = await response.blob();
  const disposition = response.headers.get("Content-Disposition") || "";
  const fileNameMatch = /filename="?([^";]+)"?/i.exec(disposition);
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = fileNameMatch?.[1] || "deadlines.xlsx";
  link.click();
  URL.revokeObjectURL(link.href);
  toast(`Excel сформирован: ${response.headers.get("X-Export-Count") || 0} строк`);
}

async function renderMailPreview() {
  const requestId = ++previewRequestId;
  const preview = $("#mailPreview");
  const template = $("#mailBodyTemplate").value;
  const events = selectedDayEvents().filter((event) => event.status !== "sent");

  if (!events.length) {
    preview.textContent = `На ${state.selectedDate} задач для контроля нет.`;
    return;
  }

  preview.textContent = "Формирую письмо...";
  try {
    const summary = await api("/api/summary/preview", {
      method: "POST",
      body: {
        date: state.selectedDate,
        eventIds: events.map((event) => event.eventId),
        mailBodyTemplate: template
      }
    });
    if (requestId === previewRequestId) preview.textContent = summary.text || "";
  } catch (error) {
    if (requestId === previewRequestId) preview.textContent = error.message || "Не удалось сформировать письмо";
  }
}

function countEventsByDate(events) {
  const counts = new Map();
  for (const event of events) {
    counts.set(event.dueDate, (counts.get(event.dueDate) || 0) + 1);
  }
  return counts;
}

function calendarCells(monthDate) {
  const first = firstDayOfMonth(monthDate);
  const start = new Date(first);
  const dayOfWeek = (first.getDay() + 6) % 7;
  start.setDate(first.getDate() - dayOfWeek);
  return Array.from({ length: 42 }, (_, index) => {
    const date = new Date(start);
    date.setDate(start.getDate() + index);
    return date;
  });
}

async function api(url, options = {}) {
  const response = await fetch(url, {
    method: options.method || "GET",
    headers: { "Content-Type": "application/json" },
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || "Ошибка запроса");
  return payload;
}

function withBusy(selector, fn) {
  return async () => {
    const button = $(selector);
    button.disabled = true;
    try {
      await fn();
    } catch (error) {
      toast(error.message || "Ошибка", true);
    } finally {
      button.disabled = false;
      if (selector === "#sendBtn") renderDay();
    }
  };
}

function toast(message, isError = false) {
  const box = $("#toast");
  box.textContent = message;
  box.style.background = isError ? "#991b1b" : "#111827";
  box.classList.add("show");
  setTimeout(() => box.classList.remove("show"), 3200);
}

function debounce(fn, delay) {
  let timer = null;
  return () => {
    clearTimeout(timer);
    timer = setTimeout(fn, delay);
  };
}

function firstDayOfMonth(date) {
  return new Date(date.getFullYear(), date.getMonth(), 1);
}

function parseIso(iso) {
  const [year, month, day] = iso.split("-").map(Number);
  return new Date(year, month - 1, day);
}

function toIso(date) {
  return [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0")
  ].join("-");
}

function todayIso() {
  return toIso(new Date());
}

function formatDate(iso) {
  return parseIso(iso).toLocaleDateString("ru-RU", {
    day: "numeric",
    month: "long",
    year: "numeric"
  });
}

function fileName(filePath = "") {
  return String(filePath).split(/[\\/]/).pop();
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function plural(count, forms) {
  const mod10 = count % 10;
  const mod100 = count % 100;
  const form = mod10 === 1 && mod100 !== 11
    ? forms[0]
    : mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)
      ? forms[1]
      : forms[2];
  return `${count} ${form}`;
}
